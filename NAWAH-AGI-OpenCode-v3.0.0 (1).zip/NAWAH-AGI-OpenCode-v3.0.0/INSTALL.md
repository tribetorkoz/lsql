# التثبيت في ثلاث خطوات

> **المتطلب الوحيد**: Python 3.10 أو أحدث. لا تبعيات، لا شبكة، لا صلاحيات
> مدير. (حزمة البحث `numpy` اختيارية ولا تمسّ الربط بـ OpenCode.)

## 1) فكّ الأرشيف داخل مشروعك

```bash
cd ~/projects/my-app
unzip ~/Downloads/NAWAH-AGI-OpenCode-v3.0.0.zip -d nawah-agi
cd nawah-agi
```

## 2) شغّل المُثبِّت

```bash
python3 install.py --project "$HOME/projects/my-app"
```

ماذا يفعل: ينشئ `.venv` → يُثبّت الحزمة → ينسخ `.opencode/` → يدمج
`opencode.json` (مع نسخة احتياطية) → يصدّر المهارات → يُشغّل الطبيب.

**Windows**:
```powershell
py -3 install.py --project "C:\Users\me\projects\my-app"
```

## 3) افتح OpenCode وتأكّد

```bash
cd ~/projects/my-app
opencode          # ثم اكتب: /nawah
```

ثم اطلب من الوكيل: «استعمل `nawah_status`، ثم `nawah_code_scan` على
`nawah/`، ثم `nawah_plan` لهدف `tests:passing`».

---

## ما الذي يتغيّر في مشروعك؟

| المسار | ماذا |
|---|---|
| `.venv/` | بيئة معزولة تحتوي الحزمة (لا تمسّ Python النظام) |
| `.nawah/` | ذاكرة NAWAH: ملاحظات، مشاهدات، مهارات متعلَّمة |
| `.opencode/agents/nawah-planner.md` | وكيل plan-first |
| `.opencode/commands/nawah.md` | الأمر `/nawah` |
| `.opencode/plugins/nawah.ts` | الإضافة التي تُغذّي الذاكرة من الأحداث |
| `.opencode/skills/*/SKILL.md` | 4 مهارات بصيغة Agent Skills |
| `opencode.json` | **مُدمَج**: مفتاح `mcp.nawah` + 11 صلاحية أدوات |

كل ملف موجود مسبقًا يُنسخ إلى `*.bak-<التاريخ>` قبل تعديله.

## الفحص والاستعمال اليومي

```bash
python3 -m nawah.doctor            # 12 فحصًا، الحكم في سطر واحد
python3 -m nawah.doctor --tests    # + 101 اختبارًا
python3 examples/code_understanding_demo.py   # فهم الكود: 100%
```

## إزالة التثبيت (تراجع كامل)

```bash
cd ~/projects/my-app
rm -rf .venv .nawah
rm -rf .opencode/agents/nawah-planner.md .opencode/commands/nawah.md \
       .opencode/plugins/nawah.ts .opencode/skills/nawah-*
# استعادة الإعداد الأصلي:
mv opencode.json.bak-<التاريخ> opencode.json
```

لا شيء خارج هذه المسارات تغيّر — لا على مستوى النظام ولا على مستوى Python
العالمي.

## مشاكل شائعة

| العرض | الحل |
|---|---|
| `No module named nawah` | استعمل `.venv/bin/python` أو `PYTHONPATH=<مجلد الحزمة>` |
| `No module named venv` | `sudo apt install python3-venv` |
| الأدوات لا تظهر في OpenCode | تحقّق من `mcp.nawah.command` في `opencode.json` وأعد تشغيل OpenCode |
| `numpy` مفقود | غير مطلوب للنواة؛ للأبحاث: `pip install numpy` |

الدليل المفصّل للوكلاء: `PROMPT_INSTALL.md`. التوثيق التقني:
`docs/OPENCODE_INTEGRATION.md`.
