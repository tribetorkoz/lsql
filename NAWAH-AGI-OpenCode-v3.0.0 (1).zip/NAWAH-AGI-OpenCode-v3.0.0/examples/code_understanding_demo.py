"""NAWAH-AGI يقرأ كوده هو — فهم بنائي + تنبؤ مُقاس بأثر التغيير."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from nawah.codeworld import (
    CodeWorld,
    diff_sources,
    edit_action,
    facts_from_source,
    facts_from_tree,
    scan_summary,
)

print("═" * 62)
print("① الفهم البنائي: قراءة كود المشروع الحقيقي")
facts = facts_from_tree("nawah")
print(f"   nawah/ package -> {scan_summary(facts)}")

print("\n② التعلّم: مشغّل تحرير حقيقي (إضافة دالة + استيراد)")
before = """import json

def save(data):
    with open("x.json", "w") as f:
        json.dump(data, f)
"""
after = """import json
import gzip

def save(data):
    with open("x.json", "wb") as f:
        gzip.dump(data, f)

def load(path):
    with open(path, "rb") as f:
        return gzip.load(f)
"""
fb = facts_from_source(before, "store")
fa = facts_from_source(after, "store")
add, dele = diff_sources(before, after, "store")
print(f"   delta: +{sorted(':'.join(map(str, a)) for a in add)}")
print(f"          -{sorted(':'.join(map(str, a)) for a in dele)}")

cw = CodeWorld()
cw.observe_edit(edit_action("extend", "store", "load"), fb, fa)

print("\n③ التنبؤ: هل يفهم أثر تحرير قبل تنفيذه؟")
imp = cw.impact(edit_action("extend", "store", "load"), fb)
print(f"   known={imp['known']}")
print(f"   predicted add: {list(imp['delta_add'])[:4]}")

print("\n④ القياس: التنبؤ ضد الحقيقة (نفس العملة الميكانيكية)")
ok = cw.score_prediction(edit_action("extend", "store", "load"), fb, fa)
print(f"   prediction correct: {ok}   accuracy: {cw.accuracy:.0%}")

print("\n⑤ النقل عبر إعادة التسمية: مشغّل تعلّمته على module A")
print("   يُطبَّق على module B (التوسط الذي جعل التدريب يعمّم):")
fb2 = facts_from_source(before, "TWIN_store")
fa2 = facts_from_source(after, "TWIN_store")
imp2 = cw.impact(edit_action("extend", "store", "load"), fb2)
print(
    f"   impact on renamed twin known={imp2['known']}"
    f"  add={list(imp2['delta_add'])[:2]}"
)
print("═" * 62)
