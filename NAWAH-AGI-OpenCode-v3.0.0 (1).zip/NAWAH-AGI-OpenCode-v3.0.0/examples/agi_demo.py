"""يوم في حياة NAWAH-AGI: حلقة كاملة من الاستكشاف إلى التطور."""

import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from nawah.agi import AgiAgent
from nawah.goals import GoalProposer
from nawah.memory import Memory
from nawah.planner import OnlinePlanner
from nawah.worldmodel import WorldModel
from nawah.worlds import SymbolicWorld, gen_level, map_heuristic

lv = gen_level(3)
w = SymbolicWorld(lv)
print(
    "① عالم مجهول بالبذرة 3:",
    f"{len(lv.rooms)} غرف، "
    f"{len(lv.locks)} أقفال، هدف مخبأ = {sorted(lv.goal)}",
)

# ② استكشاف بالفضول: يطارد الجديد، لا يكرر، لا يُسقط مفاتيحه
m = WorldModel()
rng = random.Random(3)
seen = []
for _ in range(150):
    acts = w.applicable()
    if not acts:
        break
    if rng.random() < 0.35:
        a = rng.choice(acts)
    else:
        top = max(m.novelty(w.state, x) for x in acts)
        a = rng.choice([x for x in acts if m.novelty(w.state, x) == top])
    if a.startswith("unlock") or a.startswith("take"):
        seen.append(a)
    prev = w.state
    nxt = w.step(a)
    m.observe(a, prev, nxt)
print("② استكشاف فضولي:", f"{m.coverage()}")
print("   أحداث تعلّم بارزة:", seen[:8] or "—")

# ③ تخطيط في الخيال ثم التنفيذ الحقيقي
log = OnlinePlanner(
    m, max_replans=3, max_explore=16, rng=random.Random(3)
).solve(SymbolicWorld(lv), h_fn=map_heuristic(lv))
print(
    "③ خيال + تنفيذ:",
    f"تحقق={log.achieved} في {log.steps} خطوة، "
    f"{log.plans} خطة، مفاجآت={log.surprises}",
)

# ④ اكتشاف الأهداف الذاتية
prop = GoalProposer(memory=Memory(), model=m, rule="learnability")
w3 = SymbolicWorld(lv)
best = prop.propose(w3.state, lv, w3.applicable)
print("④ اكتشاف الأهداف الذاتية (الأكثر قابلية للتعلم):")
if best is not None:
    print(
        f"   الهدف المقترح: {sorted(best.goal)}  "
        f"learnability={best.learnability:.3f}  reachable={best.reachable}"
    )
else:
    print("   (لا هدف غير تافه متاح)")

# ⑤ تطور ذاتي: جينوم جديد يُولَّد ويُقوَّم
ag = AgiAgent(seed=3)
child = ag.meta.propose_child()
score = ag.evaluate_genome(child.genes, [lv])
print(
    "⑤ تطور ذاتي (DGM-lite):",
    f"جينوم {child.gid} (من {child.parent}) "
    f"genes={child.genes}  تقييم={score:.3f}",
)
print(
    "\n⑦ الذروة: الوكيل يتعلم مشغّلات العالم ثم يحلّه في خطة قصيرة "
    "دون أن يعرف الهدف مسبقًا."
)
