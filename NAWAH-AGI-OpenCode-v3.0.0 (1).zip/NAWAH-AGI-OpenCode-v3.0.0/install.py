#!/usr/bin/env python3
"""NAWAH-AGI installer for OpenCode.

    python3 install.py                 # install here, wire this project
    python3 install.py --project DIR   # wire ANOTHER project of yours
    python3 install.py --no-venv       # use the running interpreter
    python3 install.py --check         # only run the doctor

Design rules (deliberate):
  * never overwrite a file without a timestamped backup;
  * merge opencode.json instead of replacing it;
  * work offline — pip is preferred, a .pth link is the fallback;
  * end by PROVING the result with the doctor, exit non-zero on failure.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

SRC = Path(__file__).resolve().parent
WIRED = [
    ("opencode.json", "opencode.json"),
    (".opencode/agents/nawah-planner.md", ".opencode/agents/nawah-planner.md"),
    (".opencode/commands/nawah.md", ".opencode/commands/nawah.md"),
    (".opencode/plugins/nawah.ts", ".opencode/plugins/nawah.ts"),
]
STEP = "—"


def say(msg: str) -> None:
    print(f"{STEP} {msg}", flush=True)


def fail(msg: str) -> SystemExit:
    print(f"\n✗ {msg}", file=sys.stderr)
    return SystemExit(1)


def check_python() -> None:
    if sys.version_info < (3, 10):  # noqa: UP036 - guard is the point
        raise fail(
            f"Python {sys.version_info.major}.{sys.version_info.minor} found; "
            "NAWAH-AGI needs 3.10 or newer."
        )
    say(f"python {sys.version.split()[0]} — ok")


def make_venv(dest: Path, offline: bool) -> Path:
    """Return the interpreter that can `import nawah`."""
    venv_dir = dest / ".venv"
    py = venv_dir / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if not py.exists():
        say(f"creating virtualenv at {venv_dir} …")
        subprocess.run(
            [
                sys.executable,
                "-m",
                "venv",
                "--system-site-packages",
                str(venv_dir),
            ],
            check=True,
        )
    if not py.exists():
        raise fail("virtualenv creation failed (is python3-venv installed?)")

    if not offline:
        r = subprocess.run(
            [str(py), "-m", "pip", "install", "-q", "-e", str(SRC)],
            capture_output=True,
            text=True,
        )
        if r.returncode == 0:
            say("package installed into the venv (pip -e)")
            return py
        say("pip unavailable — falling back to a path link (offline mode)")

    # offline fallback: a .pth file is enough for `import nawah`
    site = subprocess.run(
        [str(py), "-c", "import site;print(site.getsitepackages()[0])"],
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()
    Path(site, "nawah-src.pth").write_text(str(SRC) + "\n", encoding="utf-8")
    say("path link written (.pth) — offline installation")
    return py


def backup(path: Path) -> None:
    if path.exists():
        stamp = time.strftime("%Y%m%d-%H%M%S")
        shutil.copy2(path, path.with_suffix(path.suffix + f".bak-{stamp}"))
        say(f"backup: {path.name}.bak-{stamp}")


def merge_config(dest: Path, python_exe: str) -> None:
    """Wire MCP + permissions into opencode.json, preserving the user's."""
    cfg_path = dest / "opencode.json"
    backup(cfg_path)
    cfg: dict = {}
    if cfg_path.exists():
        try:
            cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            backup(cfg_path)
            say("existing opencode.json was invalid — starting a fresh one")
            cfg = {}
    cfg.setdefault("$schema", "https://opencode.ai/config.json")
    cfg.setdefault("mcp", {})
    cfg["mcp"]["nawah"] = {
        "type": "local",
        "command": [python_exe, "-m", "nawah.mcp_server"],
        "enabled": True,
    }
    perms = cfg.setdefault("permission", {})
    for tool in (
        "nawah_status",
        "nawah_observe",
        "nawah_predict",
        "nawah_applicable",
        "nawah_state_set",
        "nawah_plan",
        "nawah_replan",
        "nawah_goal_propose",
        "nawah_code_scan",
        "nawah_code_impact",
    ):
        perms.setdefault(tool, "allow")
    perms.setdefault("nawah_evolve", "ask")
    cfg_path.write_text(
        json.dumps(cfg, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    say(f"opencode.json wired -> {python_exe}")


def copy_files(dest: Path) -> None:
    for rel_src, rel_dst in WIRED:
        if rel_src == "opencode.json":
            continue
        s, d = SRC / rel_src, dest / rel_dst
        if not s.exists():
            say(f"skip (missing in source): {rel_src}")
            continue
        d.parent.mkdir(parents=True, exist_ok=True)
        if d.exists() and d.read_bytes() != s.read_bytes():
            backup(d)
        shutil.copy2(s, d)
        say(f"installed {rel_dst}")

    skills_src = SRC / ".opencode" / "skills"
    if skills_src.is_dir():
        for sk in sorted(skills_src.glob("*/SKILL.md")):
            d = dest / ".opencode" / "skills" / sk.parent.name / "SKILL.md"
            d.parent.mkdir(parents=True, exist_ok=True)
            if d.exists() and d.read_bytes() != sk.read_bytes():
                backup(d)
            shutil.copy2(sk, d)
        n = len(list(skills_src.glob("*/SKILL.md")))
        say(f"skills: {n} SKILL.md present")


def export_skills(dest: Path, python_exe: str) -> None:
    env = dict(os.environ, PYTHONPATH=str(SRC))
    r = subprocess.run(
        [
            python_exe,
            "-m",
            "nawah.oc_skills",
            str(dest / ".opencode" / "skills"),
        ],
        capture_output=True,
        text=True,
        env=env,
        cwd=str(dest),
    )
    if r.returncode == 0:
        say("skills re-exported from the live skill store")
    else:
        say("skill export skipped (using the ones shipped in the archive)")


def run_doctor(dest: Path, python_exe: str, with_tests: bool) -> int:
    env = dict(os.environ, PYTHONPATH=str(SRC), NAWAH_PROJECT=str(dest))
    args = [python_exe, "-m", "nawah.doctor"] + (
        ["--tests"] if with_tests else []
    )
    print()
    return subprocess.run(args, cwd=str(dest), env=env).returncode


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        prog="install.py",
        description="Install NAWAH-AGI and wire it into OpenCode.",
    )
    ap.add_argument(
        "--project",
        default=str(SRC),
        help="project directory to wire (default: this folder)",
    )
    ap.add_argument(
        "--no-venv",
        action="store_true",
        help="use the running interpreter instead of a venv",
    )
    ap.add_argument(
        "--offline", action="store_true", help="skip pip, use a .pth path link"
    )
    ap.add_argument("--check", action="store_true", help="run the doctor only")
    ap.add_argument(
        "--tests",
        action="store_true",
        help="also run the full test suite in the doctor",
    )
    ap.add_argument(
        "--print-prompt",
        action="store_true",
        help="print the agent prompt and exit",
    )
    a = ap.parse_args(argv)

    if a.print_prompt:
        p = SRC / "PROMPT_INSTALL.md"
        print(p.read_text(encoding="utf-8") if p.exists() else "missing")
        return 0

    dest = Path(a.project).expanduser().resolve()
    check_python()

    if a.check:
        py = (
            (dest / ".venv" / "bin/python")
            if not a.no_venv
            else sys.executable
        )
        py = str(py if Path(py).exists() else sys.executable)
        return run_doctor(dest, py, a.tests)

    print(f"NAWAH-AGI installer — target: {dest}\n")
    if not dest.exists():
        dest.mkdir(parents=True)
        say(f"created {dest}")

    python_exe = (
        sys.executable if a.no_venv else str(make_venv(dest, a.offline))
    )
    copy_files(dest)
    merge_config(dest, python_exe)
    export_skills(dest, python_exe)

    rc = run_doctor(dest, python_exe, a.tests)
    print()
    if rc == 0:
        print("✓ installation complete and verified.")
        print("  next:  open OpenCode in this folder and run  /nawah  ")
        print('         or ask the agent: "use nawah_plan before editing"')
    else:
        print("✗ the doctor reported failures above — nothing was hidden.")
        print("  fix them, then re-run:  python3 install.py --check")
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
