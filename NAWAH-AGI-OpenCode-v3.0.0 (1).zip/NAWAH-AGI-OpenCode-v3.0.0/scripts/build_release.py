"""Build a clean release archive: no caches, no venv, no local state.

    python3 scripts/build_release.py [--out DIR]

The archive is then verified by extracting it into a temp dir and running
the doctor there — a release that cannot install itself is not a release.
"""

from __future__ import annotations

import argparse
import hashlib
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent
NAME = "NAWAH-AGI-OpenCode"
VERSION = "3.0.0"
EXCLUDE_DIRS = {
    ".git",
    ".venv",
    ".nawah",
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    ".mypy_cache",
    "build",
    "dist",
    ".arena",
    ".cache",
    "node_modules",
}
EXCLUDE_FILES = {".DS_Store", "report.md"}


def wanted(p: Path) -> bool:
    rel = p.relative_to(SRC)
    if any(part in EXCLUDE_DIRS for part in rel.parts):
        return False
    if p.name in EXCLUDE_FILES or p.suffix == ".pyc":
        return False
    return not p.name.startswith("opencode.json.bak")


def files() -> list[Path]:
    out = [p for p in SRC.rglob("*") if p.is_file() and wanted(p)]
    return sorted(out, key=lambda p: str(p))


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(SRC.parent))
    ap.add_argument("--no-verify", action="store_true")
    a = ap.parse_args(argv)

    out_dir = Path(a.out).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    zip_path = out_dir / f"{NAME}-v{VERSION}.zip"
    root = f"{NAME}-v{VERSION}"

    members = files()
    sums = {p: sha256(p) for p in members}

    with zipfile.ZipFile(
        zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9
    ) as z:
        for p in members:
            z.write(p, f"{root}/{p.relative_to(SRC)}")
        z.writestr(
            f"{root}/CHECKSUMS.sha256",
            "".join(
                f"{sums[p]}  {p.relative_to(SRC).as_posix()}\n"
                for p in members
            ),
        )
        z.writestr(
            f"{root}/RELEASE.txt",
            f"{NAME} v{VERSION}\n"
            f"files: {len(members)}\n"
            f"sha256(zip): {sha256(zip_path) if zip_path.exists() else '-'}\n"
            f"verify: python3 install.py --project <dir>\n",
        )

    size = zip_path.stat().st_size
    print(f"archive : {zip_path}")
    print(f"files   : {len(members)}")
    print(f"size    : {size / 1024:.0f} KiB")
    print(f"sha256  : {sha256(zip_path)}")

    if a.no_verify:
        return 0

    print("\nverifying the archive can install itself …")
    with tempfile.TemporaryDirectory() as tmp:
        with zipfile.ZipFile(zip_path) as z:
            z.extractall(tmp)
        pkg = Path(tmp) / root
        target = Path(tmp) / "project"
        target.mkdir()
        r = subprocess.run(
            [
                sys.executable,
                str(pkg / "install.py"),
                "--project",
                str(target),
                "--no-venv",
            ],
            capture_output=True,
            text=True,
        )
        tail = (r.stdout or "").strip().splitlines()[-3:]
        print("\n".join(f"  {ln}" for ln in tail))
        if r.returncode != 0:
            print((r.stderr or "")[-800:], file=sys.stderr)
            print("RELEASE VERIFICATION FAILED", file=sys.stderr)
            return 1
        print("release verified: extracted archive installs and self-checks.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
