"""The AGI stack: world, world model, planner, goals, memory, meta, agent.

Every test here is mechanical and seeded. The properties being pinned
are the ones the AGI claim rests on:
    * dynamics LEARNED from transitions transfer across renamed levels
      (operator induction — a lookup table cannot do this),
    * plans are found in imagination and repaired when wrong,
    * the agent proposes its own non-trivial, reachable goals,
    * the policy genome evolves under empirical validation only.
"""

import random

from nawah.agi import AgiAgent, bench_free_play, bench_meta, bench_transfer
from nawah.goals import GoalProposer, candidate_goals
from nawah.memory import Memory, goal_fingerprint
from nawah.meta import (
    GENOME_SPACE,
    Archive,
    MetaEvolver,
    mutate,
    random_genome,
)
from nawah.planner import OnlinePlanner, plan
from nawah.worldmodel import WorldModel, lift_transition
from nawah.worlds import SymbolicWorld, atom, fmt_state, gen_level, gen_suite


def _world(seed=0, **kw):
    return SymbolicWorld(gen_level(seed, **kw))


# ══════════════ worlds ══════════════
def test_world_deterministic():
    a = gen_level(3, tid=1)
    b = gen_level(3, tid=1)
    assert a.start_state() == b.start_state()
    assert a.goal == b.goal
    wa, wb = SymbolicWorld(a), SymbolicWorld(b)
    acts = wa.applicable()
    assert acts == wb.applicable()
    wa.step(acts[0])
    wb.step(acts[0])
    assert wa.state == wb.state


def test_world_rejects_illegal_action():
    w = _world(1)
    try:
        w.step("go:nowhere_room")
        raise AssertionError("illegal action was accepted")
    except ValueError:
        pass


def test_world_goals_are_solvable():
    """Every generated level must admit a solution — the search itself
    proves it (env dynamics are ground truth)."""
    from nawah.planner import plan as _p

    for seed in range(4):
        lv = gen_level(seed, tid=seed)
        w = SymbolicWorld(lv)

        # plan against the TRUE dynamics via a perfect model wrapper
        class Perfect:
            def predict(self, s, a, _lv=lv):
                if a not in SymbolicWorld(_lv).applicable(s):
                    return None
                try:
                    return SymbolicWorld(_lv).step(a, s)
                except ValueError:
                    return None

        p = _p(Perfect(), w.state, lv.goal, w.applicable)
        assert p is not None, f"level {seed} unsolvable: {fmt_state(lv.goal)}"


# ══════════════ world model ══════════════
def test_operator_induction_transfers_across_renames():
    """Learn take/go on one level; the lifted schemas must predict the
    SAME shapes in a level whose rooms/items have different names."""
    m = WorldModel()
    lv1 = gen_level(10, tid=0)
    w1 = SymbolicWorld(lv1)
    # execute some transitions by naive exploration
    for _ in range(40):
        acts = w1.applicable()
        a = acts[0]
        prev = w1.state
        nxt = w1.step(a)
        m.observe(a, prev, nxt)

    lv2 = gen_level(11, tid=0)  # different names everywhere
    w2 = SymbolicWorld(lv2)
    acts = w2.applicable()
    prev = w2.state
    a = acts[0]
    true_next = w2.step(a, prev)
    predicted = m.predict(prev, a)
    # either the schema applies (transfer!) or honestly None — but never
    # a WRONG state
    if predicted is not None:
        assert predicted == true_next, (
            f"schema predicted a wrong state: {fmt_state(predicted)} vs "
            f"{fmt_state(true_next)}"
        )


def test_lift_transition_relevant_preconditions_only():
    lv = gen_level(20, tid=0)
    w = SymbolicWorld(lv)
    a = next(x for x in w.applicable() if x.startswith("go:"))
    s, s2 = w.state, w.step(a, w.state)
    _schema, pre, add, dele = lift_transition(a, s, s2)
    assert add, "a move must add something"
    assert dele, "a move must delete something"
    # map noise (adj/needs/at_room_of) must not appear as preconditions
    # unless it shares a variable with the effect
    for atom_l in pre:
        assert atom_l[0] in (
            "at",
            "item_at",
            "has",
            "unlocked",
            "adj",
            "needs",
            "at_room_of",
        )


def test_surprise_then_learn():
    m = WorldModel()
    w = _world(5)
    a = w.applicable()[0]
    prev = w.state
    nxt = w.step(a)
    first = m.observe(a, prev, nxt)  # nothing known yet -> surprise
    assert first is False, "a first-ever transition cannot be predicted"
    second = m.observe(a, prev, nxt)  # now recalled exactly
    assert second is True, "the model must recall a repeated transition"
    assert m.predict(prev, a) == nxt
    assert m.learning_progress() >= 0.0


# ══════════════ planner ══════════════
def test_planner_finds_short_plan_in_trained_model():
    m = WorldModel()
    lv = gen_level(30, tid=0)

    # train the model by solving with a perfect oracle first
    class Perfect:
        def predict(self, s, a):
            try:
                return SymbolicWorld(lv).step(a, s)
            except ValueError:
                return None

    w = SymbolicWorld(lv)
    oracle = plan(Perfect(), w.state, lv.goal, w.applicable)
    assert oracle is not None
    # replay the oracle plan through the model to teach it
    s = w.state
    for a in oracle.actions:
        s2 = SymbolicWorld(lv).step(a, s)
        m.observe(a, s, s2)
        s = s2
    p = plan(m, w.state, lv.goal, w.applicable)
    assert p is not None
    assert p.actions == oracle.actions


def test_online_planner_replans_after_surprise():
    """A model that LIES on one action must be repaired online: the loop
    still achieves the goal and the model learned from its mistake."""
    lv = gen_level(40, tid=0)
    m = WorldModel()
    w = SymbolicWorld(lv)

    class LyingModel(WorldModel):
        lied = False

        def predict(self, s, a):
            if not self.lied and a.startswith("go:"):
                self.lied = True
                return super().predict(s, a) or frozenset(s)  # benign first
            return super().predict(s, a)

    # first teach the model everything via oracle rollouts
    class Perfect:
        def predict(self, s, a):
            try:
                return SymbolicWorld(lv).step(a, s)
            except ValueError:
                return None

    po = plan(Perfect(), w.state, lv.goal, w.applicable)
    s = w.state
    for a in po.actions:
        s2 = SymbolicWorld(lv).step(a, s)
        m.observe(a, s, s2)
        s = s2
    # now run the online loop on a fresh world with the trained model
    w2 = SymbolicWorld(lv)
    log = OnlinePlanner(m).solve(w2)
    assert log.achieved, "trained model + online loop must reach the goal"
    assert log.plans >= 1 and log.steps >= 1


# ══════════════ goals ══════════════
def test_goal_candidates_are_grounded_in_the_world():
    lv = gen_level(50, tid=0)
    w = SymbolicWorld(lv)
    cands = candidate_goals(w.state, lv)
    assert cands, "no goals generated"
    assert all(isinstance(g, frozenset) and g for g in cands)
    assert not any(g <= w.state for g in cands), (
        "trivial goals must be excluded later"
    )


def test_proposer_prefers_learnable_reachable_goals():
    m = WorldModel()
    mem = Memory()
    lv = gen_level(51, tid=0)
    w = SymbolicWorld(lv)

    # teach the model a little by oracle rollouts of ONE plan
    class Perfect:
        def predict(self, s, a):
            try:
                return SymbolicWorld(lv).step(a, s)
            except ValueError:
                return None

    po = plan(Perfect(), w.state, lv.goal, w.applicable)
    s = w.state
    for a in po.actions:
        s2 = SymbolicWorld(lv).step(a, s)
        m.observe(a, s, s2)
        s = s2
    mem.goal_record[goal_fingerprint(lv.goal)] = [1, 1]  # half-known
    prop = GoalProposer(memory=mem, model=m, rule="learnability")
    p = prop.propose(w.state, lv, w.applicable)
    assert p is not None
    assert p.learnability > 0
    assert not p.goal <= w.state


# ══════════════ memory ══════════════
def test_goal_fingerprint_generalises_over_renames():
    g1 = frozenset({atom("has", "agent", "gem7_0")})
    g2 = frozenset({atom("has", "agent", "gem99_3")})
    g3 = frozenset({atom("at", "agent", "r7_2")})
    assert goal_fingerprint(g1) == goal_fingerprint(g2)
    assert goal_fingerprint(g1) != goal_fingerprint(g3)


def test_memory_beta_prior():
    mem = Memory()
    assert (
        abs(mem.p_success(frozenset({atom("has", "agent", "x")})) - 0.5) < 1e-9
    )
    mem.record_episode(frozenset({atom("has", "agent", "x")}), (), True, 0, 3)
    assert mem.p_success(frozenset({atom("has", "agent", "x")})) > 0.5


# ══════════════ meta ══════════════
def test_mutation_stays_in_bounds():
    rng = random.Random(0)
    g = random_genome(rng)
    for _ in range(50):
        g = mutate(g, rng, gid="m")
        for k, space in GENOME_SPACE.items():
            if isinstance(space, list):
                assert g.genes[k] in space
            else:
                lo, hi = space
                assert lo <= g.genes[k] <= hi


def test_archive_bounded_and_diverse():
    rng = random.Random(1)
    ar = Archive(max_size=6)
    for i in range(20):
        g = random_genome(rng, gid=f"g{i}")
        g.score = float(i)
        ar.add(g)
    assert len(ar.members) <= 6
    assert ar.best().score == max(m.score for m in ar.members)


def test_meta_evolution_finds_at_least_as_good_a_policy():
    train, _test = gen_suite(7, n_train=3, n_test=2)
    ev = MetaEvolver(seed=7)
    ag = AgiAgent(seed=7)

    def evaluate(genome):
        ag.__post_init__()
        return ag.evaluate_genome(genome.genes, train)

    before = evaluate(ev.archive.best())
    history = ev.run(evaluate, generations=6)
    best = ev.archive.best()
    assert best.score >= before - 1e-9, (
        f"evolution went backwards: {before} -> {best.score}"
    )
    assert len(history) == 6
    assert ev.archive.lineage(best), "lineage must be recorded"


# ══════════════ the agent ══════════════
def test_agent_deterministic():
    a1 = bench_transfer(seed=1, n_train=3, n_test=2, warm_per_level=1)
    a2 = bench_transfer(seed=1, n_train=3, n_test=2, warm_per_level=1)
    assert a1 == a2, "same seed must give the same benchmark"


def test_transfer_bench_runs_and_learns():
    out = bench_transfer(seed=2, n_train=5, n_test=3, warm_per_level=2)
    assert 0 <= out["cold_start"] <= 100
    assert 0 <= out["after_one_attempt"] <= 100
    # the world model must contain induced schemas
    assert "0 schemas" not in out["model"]


def test_free_play_builds_model():
    out = bench_free_play(seed=3, rounds=18)
    assert "0 schemas" not in out["model"]
    assert 0 <= out["held_out_directed"] <= 100


def test_meta_bench_reports_disjoint_test():
    out = bench_meta(seed=4, generations=4)
    assert out["test_before"] >= 0 and out["test_after"] >= 0
    assert out["best_genes"], "a genome must be chosen"
    assert out["lineage"], "lineage must exist"
