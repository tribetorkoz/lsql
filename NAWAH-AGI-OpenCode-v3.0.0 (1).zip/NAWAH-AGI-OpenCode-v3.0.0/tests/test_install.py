"""The installer is a promise to strangers — it gets tested like one."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _run(*args, cwd=None):
    return subprocess.run(
        [sys.executable, *args],
        cwd=cwd or ROOT,
        capture_output=True,
        text=True,
        timeout=600,
    )


def test_doctor_reports_json_and_is_healthy():
    r = _run("-m", "nawah.doctor", "--json")
    assert r.returncode == 0, r.stderr[-800:]
    data = json.loads(r.stdout)
    assert data["ok"] is True
    names = {c["name"] for c in data["checks"]}
    assert {"python", "mcp handshake", "world model"} <= names
    assert len(data["checks"]) >= 10


def test_installer_wires_a_fresh_project(tmp_path):
    r = _run("install.py", "--project", str(tmp_path), "--no-venv")
    assert r.returncode == 0, r.stdout[-800:] + r.stderr[-800:]
    assert "installation complete and verified" in r.stdout

    cfg = json.loads((tmp_path / "opencode.json").read_text())
    cmd = cfg["mcp"]["nawah"]["command"]
    assert cmd[1:] == ["-m", "nawah.mcp_server"]
    assert cfg["permission"]["nawah_plan"] == "allow"
    assert cfg["permission"]["nawah_evolve"] == "ask"

    for rel in (
        ".opencode/plugins/nawah.ts",
        ".opencode/agents/nawah-planner.md",
        ".opencode/commands/nawah.md",
    ):
        assert (tmp_path / rel).is_file(), rel
    assert len(list((tmp_path / ".opencode/skills").glob("*/SKILL.md"))) == 4
    assert (tmp_path / ".nawah").is_dir()


def test_installer_merges_instead_of_overwriting(tmp_path):
    existing = {
        "$schema": "https://opencode.ai/config.json",
        "theme": "user-theme",
        "mcp": {"other": {"type": "local", "command": ["x"]}},
        "permission": {"bash": "ask"},
    }
    cfg_path = tmp_path / "opencode.json"
    cfg_path.write_text(json.dumps(existing))

    r = _run("install.py", "--project", str(tmp_path), "--no-venv")
    assert r.returncode == 0, r.stderr[-800:]

    merged = json.loads(cfg_path.read_text())
    assert merged["theme"] == "user-theme"  # user keys survive
    assert merged["mcp"]["other"]["command"] == ["x"]
    assert merged["permission"]["bash"] == "ask"
    assert merged["mcp"]["nawah"]["type"] == "local"
    assert any(
        p.name.startswith("opencode.json.bak-") for p in tmp_path.iterdir()
    )


def test_core_package_needs_no_third_party_import():
    """The MCP path must import with a bare interpreter."""
    code = (
        "import sys\n"
        "class Block:\n"
        "    def find_module(self, name, path=None):\n"
        "        if name.split('.')[0] in {'numpy','yaml','requests'}:\n"
        "            raise ModuleNotFoundError(name)\n"
        "sys.meta_path.insert(0, Block())\n"
        "import nawah, nawah.mcp_server, nawah.codeworld, nawah.oc_driver\n"
        "print('ok')\n"
    )
    r = _run("-c", code)
    assert r.returncode == 0, r.stderr[-800:]
    assert "ok" in r.stdout
