"""The OpenCode bridge, tested the way we test everything here:
mechanically, with seeds, against real subprocesses and real bytes.
"""

from __future__ import annotations

import json
import re
import subprocess
import sys
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

from nawah.mcp_server import Brain, facts_to_state, state_to_facts
from nawah.oc_skills import export_skills, skill_md
from nawah.worldmodel import WorldModel

_NAME_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")

ROOT = "/home/user/KJS"


# ── MCP server over real stdio ──────────────────────────────────────
class McpProc:
    def __init__(self):
        self.p = subprocess.Popen(
            [sys.executable, "-m", "nawah.mcp_server"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            cwd=ROOT,
            text=True,
        )
        self._id = 0

    def send(self, method, params=None, notify=False):
        self._id += 1
        msg = {"jsonrpc": "2.0", "method": method}
        if not notify:
            msg["id"] = self._id
        if params is not None:
            msg["params"] = params
        self.p.stdin.write(json.dumps(msg) + "\n")
        self.p.stdin.flush()
        if notify:
            return None
        return json.loads(self.p.stdout.readline())

    def tool(self, name, args=None):
        r = self.send("tools/call", {"name": name, "arguments": args or {}})
        assert not r["result"]["isError"], r
        return json.loads(r["result"]["content"][0]["text"])

    def close(self):
        self.p.stdin.close()
        self.p.wait(timeout=10)


def test_mcp_handshake_tools_and_plan_cycle():
    m = McpProc()
    try:
        r = m.send("initialize", {"protocolVersion": "2025-06-18"})
        assert r["result"]["serverInfo"]["name"] == "nawah-agi"
        m.send("notifications/initialized", notify=True)
        tools = m.send("tools/list")["result"]["tools"]
        names = {t["name"] for t in tools}
        assert {
            "nawah_plan",
            "nawah_observe",
            "nawah_replan",
            "nawah_evolve",
            "nawah_status",
        } <= names
        # every tool has a schema OpenCode can validate against
        for t in tools:
            assert t["inputSchema"]["type"] == "object"
            assert t["description"]

        # learn a two-step flag world (facts, no action args): the
        # second step genuinely needs the first
        m.tool(
            "nawah_observe",
            {"action": "enable-a", "before": [], "after": ["a:on"]},
        )
        m.tool(
            "nawah_observe",
            {
                "action": "enable-b",
                "before": ["a:on"],
                "after": ["a:on", "b:on"],
            },
        )
        m.tool("nawah_state_set", {"facts": []})
        r = m.tool("nawah_plan", {"goal": ["a:on", "b:on"]})
        assert r["plan"] == ["enable-a", "enable-b"]
        assert r["from_cache"] is False
        # identical request must come from the case cache
        m.tool("nawah_state_set", {"facts": []})
        r2 = m.tool("nawah_plan", {"goal": ["a:on", "b:on"]})
        assert r2["from_cache"] is True
        # surprise: the world said no -> replan path returns a plan
        r3 = m.tool(
            "nawah_replan",
            {"goal": ["a:on", "b:on"], "failed_action": "enable-b"},
        )
        assert "plan" in r3
    finally:
        m.close()


def test_mcp_tool_error_is_reported_not_fatal():
    m = McpProc()
    try:
        m.send("initialize", {})
        r = m.send("tools/call", {"name": "nawah_nope", "arguments": {}})
        assert r["result"]["isError"] is True
        # server still alive
        r = m.send("tools/call", {"name": "nawah_status", "arguments": {}})
        assert r["result"]["isError"] is False
    finally:
        m.close()


# ── skills export ───────────────────────────────────────────────────
def test_skills_export_matches_agent_skills_spec(tmp_path):
    written = export_skills(tmp_path, include_meta=True)
    assert len(written) >= 4
    for name in written:
        assert _NAME_RE.match(name) and len(name) <= 64
        text = (tmp_path / name / "SKILL.md").read_text()
        assert text.startswith("---\n")
        head = text.split("\n---\n")[0]
        assert f"name: {name}" in head
        m = re.search(r"description: (.*)", head)
        assert m and 1 <= len(m.group(1).strip()) <= 1024


def test_skill_md_normalises_description():
    md = skill_md("x-y", "a  b\n   c", "body")
    head = md.split("\n---\n")[0]
    assert "description: a b c" in head


def test_export_covers_learned_operators(tmp_path):
    m = WorldModel()
    s = facts_to_state(["at:hall"])
    s2 = facts_to_state(["at:hall", "door:open"])
    m.observe("open:door", s, s2)
    written = export_skills(tmp_path, include_meta=False, model=m)
    assert any(n.startswith("nawah-op-") for n in written)


# ── observe CLI + replay ────────────────────────────────────────────
def test_oc_observe_cli_appends_and_replays(tmp_path):
    store = tmp_path / "obs.jsonl"
    for i in range(3):
        out = subprocess.run(
            [
                sys.executable,
                "-m",
                "nawah.oc_observe",
                "--action",
                f"step:{i}",
                "--before",
                f"n:{i}",
                "--after",
                f"n:{i + 1}",
                "--store",
                str(store),
            ],
            capture_output=True,
            text=True,
            cwd=ROOT,
        )
        assert out.returncode == 0
    lines = store.read_text().strip().splitlines()
    assert len(lines) == 3
    from nawah.oc_observe import load_observations, replay

    obs = load_observations(store)
    b = replay(obs)
    assert {"step:0", "step:1", "step:2"} <= b.actions_seen


# ── planner upgrades ────────────────────────────────────────────────
def test_plan_cache_hits_and_invalidate():
    from nawah.mcp_server import Brain

    b = Brain()
    b.observe("go:r1", ["at:r0"], ["at:r1"])
    b.state = facts_to_state(["at:r0"])
    r1 = b.plan(["at:r1"])
    assert r1["plan"] == ["go:r1"]
    b.state = facts_to_state(["at:r0"])
    r2 = b.plan(["at:r1"])
    assert r2["from_cache"] is True
    dropped = b.cache.invalidate_goal(facts_to_state(["at:r1"]))
    assert dropped == 1


def test_plan_hierarchical_splits_multi_fact_goals():
    b = Brain()
    b.observe("get-key", ["at:hall"], ["at:hall", "has:key"])
    b.observe(
        "open-door",
        ["at:hall", "has:key"],
        ["at:hall", "has:key", "door:open"],
    )
    b.observe(
        "enter", ["at:hall", "door:open"], ["at:room", "has:key", "door:open"]
    )
    goal = facts_to_state(["at:room", "door:open"])
    b.state = facts_to_state(["at:hall"])
    r = b.plan(state_to_facts(goal))
    assert r["plan"] is not None
    assert len(r["plan"]) == 3


# ── the orchestrator loop against a mock OpenCode server ────────────
class _MockOpenCode(BaseHTTPRequestHandler):
    """Speaks just enough OpenCode API to close the loop."""

    log = []
    state = {"step": 0}

    def _send(self, code, obj):
        raw = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        ln = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(ln) or b"{}")
        if self.path == "/session":
            _MockOpenCode.state["step"] = 0
            return self._send(200, {"data": {"id": "sess-1"}})
        if self.path.startswith("/session/") and self.path.endswith(
            "/message"
        ):
            text = body.get("parts", [{}])[0].get("text", "")
            _MockOpenCode.log.append(text)
            # executing "step:N" flips fact n to done
            _MockOpenCode.state["step"] += 1
            return self._send(200, {"data": {"ok": True}})
        return self._send(404, {"error": "nope"})

    def do_GET(self):
        return self._send(200, {"data": []})

    def log_message(self, *a):
        pass


def test_orchestrator_plan_execute_surprise_replan():
    from nawah.oc_driver import OpenCodeClient, Orchestrator

    srv = HTTPServer(("127.0.0.1", 0), _MockOpenCode)
    port = srv.server_address[1]
    th = threading.Thread(target=srv.serve_forever, daemon=True)
    th.start()
    _MockOpenCode.log = []

    # the world: two facts must flip to done; the probe reads a mutable
    # "world" that the mock server flips when prompted
    world = {"done": []}

    def probe():
        return [f"{name}:done" for name in world["done"]]

    client = OpenCodeClient(f"http://127.0.0.1:{port}")
    sid = client.create_session("t")
    assert sid == "sess-1"

    # pre-learn the operators: two flag-adding steps, the second
    # requiring the first (no action args -> no teleporting)
    b = Brain()
    b.observe("step-one", [], ["one:done"])
    b.observe("step-two", ["one:done"], ["one:done", "two:done"])

    orch = Orchestrator(client, sid, brain=b, probe=probe)
    # each prompt makes the mock "execute": the probe world advances
    orig_prompt = client.prompt

    def prompt(sid_, text, agent="build"):
        r = orig_prompt(sid_, text, agent=agent)
        if "step-one" in text:
            world["done"] = ["one"]
        elif "step-two" in text:
            world["done"] = ["one", "two"]
        return r

    client.prompt = prompt
    result = orch.run(["one:done", "two:done"], "finish the two-step task")
    assert result["success"] is True
    assert result["steps"] == ["step-one", "step-two"]
    assert len(_MockOpenCode.log) == 2
    srv.shutdown()


# ── code as a world: NAWAH reads and predicts code ──────────────────
def test_code_facts_from_real_source():
    from nawah.codeworld import facts_from_file, scan_summary

    facts = facts_from_file(f"{ROOT}/nawah/memory.py")
    kinds = {a[0] for a in facts}
    assert {"module", "defines", "imports", "loc"} <= kinds
    names = {a[2] for a in facts if a[0] in ("defines", "class")}
    assert "Memory" in names or any("mem" in n.lower() for n in names)
    s = scan_summary(facts)
    assert s["functions"] > 0 and not s["invalid"]


def test_code_edit_delta_and_prediction_transfer():
    """The rooms-and-keys promise, now over code: learn an edit
    operator on one module, predict it on a renamed twin."""
    from nawah.codeworld import CodeWorld, diff_sources, edit_action

    before = "import os\n\ndef alpha():\n    return os.name\n"
    after = (
        "import os\nimport sys\n\ndef alpha():\n    return os.name\n"
        "\ndef beta():\n    return sys.version\n"
    )
    add, _dele = diff_sources(before, after, module="moda")
    assert ("defines", "moda", "beta") in add
    assert ("imports", "moda", "sys") in add

    cw = CodeWorld()
    cw.observe_edit(
        edit_action("extend", "moda", "beta"),
        set(
            __import__("nawah.codeworld").codeworld.facts_from_source(
                before, "moda"
            )
        ),
        set(
            __import__("nawah.codeworld").codeworld.facts_from_source(
                after, "moda"
            )
        ),
    )
    from nawah.codeworld import facts_from_source

    ok = cw.score_prediction(
        edit_action("extend", "moda", "beta"),
        facts_from_source(before, "moda"),
        facts_from_source(after, "moda"),
    )
    assert ok is True
    imp = cw.impact(
        edit_action("extend", "moda", "beta"),
        facts_from_source(before, "moda"),
    )
    assert imp["known"] is True
    assert any("beta" in x for x in imp["delta_add"])
    assert cw.accuracy == 1.0


def test_oracle_facts_are_measured():
    from nawah.codeworld import oracle_facts

    ok = oracle_facts("true", tag="build")
    bad = oracle_facts("false", tag="build")
    assert ok == {("build", "passing")}
    assert bad == {("build", "failing")}
