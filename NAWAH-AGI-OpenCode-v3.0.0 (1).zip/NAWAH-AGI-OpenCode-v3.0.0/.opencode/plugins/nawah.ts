/**
 * nawah.ts — the living ear of NAWAH-AGI inside OpenCode.
 *
 * Feeds every meaningful tool outcome to the NAWAH world model so the
 * brain behind the MCP tools learns what actually happens in YOUR repo:
 * which commands pass, which edits surprise it, what "done" looks like.
 *
 * Runs as an OpenCode plugin (.opencode/plugins/, auto-discovered).
 * Observations are appended to .nawah/obs.jsonl via the nawah CLI —
 * the same store the MCP server replays on boot.
 */
import { spawnSync } from "node:child_process";

/* Interpreter that can import the nawah package. install.py writes the
 * absolute venv path here; NAWAH_PYTHON overrides it at runtime. */
const PY: string = process.env.NAWAH_PYTHON ?? "python3";

function feed(action: string, before: string[], after: string[]) {
  // a fact never contains a comma; an empty side stays empty
  try {
    spawnSync(
      PY,
      ["-m", "nawah.oc_observe", "--action", action,
       "--before", before.filter(Boolean).join(","),
       "--after", after.filter(Boolean).join(",")],
      { cwd: process.cwd(), timeout: 5000 },
    );
  } catch {
    /* never break the coding session because a brain sneezed */
  }
}

const hooks = {
  /** after every tool call: record (tool, outcome facts) */
  "tool.execute.after": async (input: any, _output: any) => {
    const tool = input?.tool ?? input?.metadata?.name ?? "unknown";
    const ok = !(_output?.metadata?.error || _output?.error);
    feed(`tool:${tool}`,
      [`ran:${tool}`],
      [`ran:${tool}`, ok ? "result:ok" : "result:error"]);
  },

  /** after every file edit: the world changed — say how */
  "file.edited": async (input: any) => {
    const p = input?.path ?? input?.file ?? "unknown";
    feed(`edit:${p}`, [`file:${p}:edited`], [`file:${p}:edited`]);
  },

  /** session start: baseline state probe */
  "session.updated": async () => {
    feed("session:pulse", ["session:active"], ["session:active"]);
  },
};

export default hooks;
