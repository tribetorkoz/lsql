---
description: NAWAH-AGI status + plan for the current task
---

Run `nawah_status` and show me the learned model coverage, plan-cache
statistics, and current state facts. Then ask me for the goal of the
current task as a list of facts and call `nawah_plan` for it. Show the
plan as a numbered checklist and execute step 1 only after I confirm.
