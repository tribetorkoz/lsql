---
name: nawah-self-improve
description: Use when the task was hard and the agent wants to improve its own planning. Runs nawah_evolve (DGM-lite) on the session's tasks and reports evolved planning genes with lineage. Sparingly — it is a measured improvement step, not a magic word.
---

# Self-improve (DGM-lite)

## When to use
End of a hard session, or when plans keep failing.

## Procedure
1. `nawah_evolve` with `generations: 4-8`.
2. Read `best_genes` and `lineage`. If `curve` rises, the evolved
   planner genes beat the seed on this session's tasks.
3. Report the numbers. Never claim improvement without the curve.

## Why
Self-improvement that is not measured is wishful thinking. The DGM
lesson (51.4 = 51.4): improvements must survive a held-out check.
