---
name: nawah-replan-on-surprise
description: Use when reality contradicts expectations: a test that should pass fails, an edit conflicts, a command errors. Teaches nawah_replan + nawah_observe: record the surprise, refine the model, get a fresh plan instead of looping.
---

# Replan on surprise

## When to use
Any moment the world said "no": red tests, build errors, unexpected
diffs, permission denials.

## Procedure
1. `nawah_observe` the failed action: before facts = what you expected
   to hold, after facts = what actually holds. `surprise: true` means
   the model just learned something.
2. `nawah_replan` with the same goal and `failed_action`.
3. Follow the new plan. Two failures on the same action = stop and
   ask the user; the model has no theory for this situation.

## Why
The world model refines lifted operators on every surprise. One
observation of failure is information; three in a row is a question.
