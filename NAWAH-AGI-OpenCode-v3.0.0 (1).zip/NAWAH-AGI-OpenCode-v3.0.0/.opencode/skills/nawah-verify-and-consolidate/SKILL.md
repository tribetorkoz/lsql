---
name: nawah-verify-and-consolidate
description: Use AFTER completing a task. Teaches the NAWAH close-out: verify the goal facts actually hold, then let NAWAH consolidate the episode into reusable skill knowledge.
---

# Verify and consolidate

## When to use
Task complete, or a meaningful milestone reached.

## Procedure
1. Re-derive the goal facts (run the checks, read the files) and call
   `nawah_state_set` with the verified facts.
2. `nawah_plan` with the goal: `solved_at_start: true` is the
   machine-checked claim of completion.
3. Record the episode outcomes via `nawah_observe` for any step whose
   result was not already logged.

## Why
NAWAH's claim is that experience should survive. An unverified "done"
is a rumor; a verified one is a skill.
