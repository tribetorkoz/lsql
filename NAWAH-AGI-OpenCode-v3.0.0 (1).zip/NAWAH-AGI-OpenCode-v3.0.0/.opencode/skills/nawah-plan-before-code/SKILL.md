---
name: nawah-plan-before-code
description: Use BEFORE multi-step coding tasks. Teaches the nawah_plan workflow: set the current state as facts, define the goal as facts, get an ordered action plan from the NAWAH-AGI world model, then execute step by step. Cuts wasted edits.
---

# Plan before code with NAWAH-AGI

## When to use
Multi-step tasks: new features, refactors across files, bug fixes with
several hypotheses, anything where you would otherwise improvise.

## Procedure
1. Describe the CURRENT world as facts (MCP tool `nawah_state_set`):
   `["tests:failing", "file:auth.py:missing", "deps:installed"]`
2. Describe the GOAL as facts: `["tests:passing", "file:auth.py:exists"]`
3. Call `nawah_plan` with that goal. It returns an ordered action list
   learned from experience (or from the lifted operator model).
4. Execute the plan actions in order. After each meaningful action,
   call `nawah_observe` with (action, before, after) facts — this is
   how the model stays honest.
5. If reality diverges (a test fails), call `nawah_replan` with the
   goal and the failed action — do NOT keep improvising.

## Why
A blind search through edits is the 25% branch. The planned branch
scores 100% at a quarter of the steps (measured: bench_compare).
