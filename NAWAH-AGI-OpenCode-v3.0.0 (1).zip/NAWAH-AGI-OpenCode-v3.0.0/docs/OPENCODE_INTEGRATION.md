# تكامل NAWAH-AGI مع OpenCode — بحث معمّق وتصميم تنفيذي
(بحث الإنترنت: أكتوبر 2026 — كل التفاصيل المذكورة موثّقة من المصادر في القسم 8)

---

## 1) ما هو OpenCode فعلاً — الصورة الكاملة (2026)

**تحذير الاسم أولًا**: هناك مشروعان بالاسم نفسه:
- `opencode-ai/opencode` (نسخة Go القديمة) — **متوقف عن الصيانة منذ سبتمبر 2025**.
- **`anomalyco/opencode`** (سابقًا `sst/opencode`) — **المشروع النشط**، بُني بواسطة Anomaly (فريق SST سابقاً). TypeScript + Bun. رخصة MIT. أول إصدار مايو 2025، والمستقر حاليًا من فرع 1.18.x مع معمارية V2 (أكتوبر 2026).

**ما هو**: وكيل برمجة مفتوح المصدر — "طبقة أدوات وذاكرة وواجهة حول أي نموذج لغوي". ليس نموذجًا بنفسه: يدعم **75+ مزودًا** (Anthropic, OpenAI, Google, محليات عبر Ollama/LM Studio/vLLM) عبر Vercel AI SDK + سجل models.dev.

**المعمارية**:
```
TUI ─┐
Desktop (Electron, beta) ─┤
IDE (VS Code/ACP) ────────┤── HTTP (Hono) ── الوكيل: حلقة "التريليون دولار"
Web / opencode pair ──────┤   OpenAPI 3.1 في /doc → SDK مُولَّد
GitHub/GitLab workflows ──┘   SQLite + Drizzle (جلسات) · SSE للأحداث
```
- `opencode` = TUI + خادم محلي. `opencode serve` = خادم headless على `127.0.0.1:4096`. `opencode attach <url>` = اتصال عن بُعد.
- الوكلاء المدمجون: **build** (كامل الصلاحيات)، **plan** (تحليل فقط — لا يُعدّل إلا `.opencode/plans/*.md`)، **general** (وكيل فرعي متعدد الخطوات)، **explore** (استكشاف قراءة فقط)، **scout** (بحث ويب). وكلاء مخصّصون عبر `.opencode/agents/<name>.md`.
- الأدوات المدمجة: bash, edit, write, read, grep, glob, lsp, apply_patch, skill, webfetch/search, task.
- ملف التعليمات: **AGENTS.md** (V2 يقرأه فقط — لا CLAUDE.md).

## 2) سطوح التوسعة الخمسة — "قائمة الربط" (هذا هو جوهر البحث)

| السطح | الموقع | يُفعَّل بـ | قوة الربط مع NAWAH |
|---|---|---|---|
| **Agent Skills** | `.opencode/skills/<name>/SKILL.md` (و`.claude/skills/` و`.agents/skills/` — المعيار المفتوح!) | اكتشاف تلقائي: النموذج يرى الوصف ويحمّل عند الحاجة (progressive loading ~100 token) | ⭐⭐⭐⭐⭐ — NAWAH أصلًا "طبقة مهارات"! |
| **MCP servers** | `opencode.json → mcp` (local stdio أو remote HTTP/SSE + OAuth) | الأدوات تدخل سجل الأدوات **كأدوات مدمجة تمامًا** (نفس بوابة الصلاحيات `server:tool`، نفس hooks الإضافات) | ⭐⭐⭐⭐⭐ — الجسر الطبيعي لدوائر NAWAH-AGI |
| **Plugins** | `.opencode/plugins/*.{js,ts}` أو npm | أحداث دورة الحياة: نداءات الأدوات، تعديلات الملفات، الجلسات | ⭐⭐⭐⭐ — "الأذن": تغذية ذاكرة NAWAH بالمفاجآت والنجاحات |
| **Custom agents** | `.opencode/agents/*.md` | Tab أو @name | ⭐⭐⭐ — كائنات DGM التي تتطور (prompts + خطوات) |
| **SDK** | `@opencode-ai/sdk` (V1) أو `@opencode/client` + `@opencode/sdk` (V2 مضمّن) | `createOpencodeClient({baseUrl})` → session.create/prompt، `event.subscribe()`, مخرجات منظمة json_schema | ⭐⭐⭐⭐⭐ — NAWAH-AGI كـ"دمج" يقود الجلسات |
| أوامر مخصّصة | `.opencode/commands/*.md` | /name | ⭐⭐ — اختصارات تشغيل المقاييس |

**ملاحظة V2** (أكتوبر 2026): API إضافات جديد، SDK صار `@opencode/client`، خادم مشترك في الخلفية، `opencode pair` للوصول من المتصفح، واكتشاف تلقائي للنماذج المحلية.

## 3) خمسة تصاميم للربط — من الأسرع إلى الأعمق

### A) جسر المهارات (الأسرع — ساعات)
**الفكرة**: NAWAH يقطّر المهارات المتحقق منها → محوّل (adapter) يكتبها بصيغة Agent Skills:
```yaml
---
name: nawah-fix-race-condition
description: استخدم هذه المهارة عند إصلاح سباقات التزامن في async — تُظهر...
license: MIT
metadata: { source: "nawah-consolidate", verified: "true", n_success: "12" }
---
## الخطوات (من ملف مهارة NAWAH المُتحقَّق)...
```
يُكتب في `.opencode/skills/<name>/SKILL.md` → **اكتشاف تلقائي** من OpenCode (و`.claude/` و`.agents/` مدعومة أيضًا = توافق مع Codex/Cursor). موجّه NAWAH الأصلي (router) يبقى اختياريًا كـ command `/nawah-which`.
**العيب**: أحادي الاتجاه (NAWAH → OpenCode) بلا حلقة تعلّم حية.

### B) خادم MCP — دوائر NAWAH-AGI كأدوات (القلب — أيام)
**الفكرة**: خادم Python رسمي (`mcp` SDK) يلفّ مكدّس NAWAH-AGI:
| أداة MCP | تلفّ | قيمتها للوكيل البرمجي |
|---|---|---|
| `nawah_learn` | worldmodel.observe/lift | يبني نموذج "مشغّلات" المهمة (ما ينجح وما يكسر الاختبارات) |
| `nawah_plan` | planner (GBFS في الخيال + map_heuristic) | خطة خطوات مُتحقَّقة قبل الغرق في التنفيذ |
| `nawah_replan` | مفاجآت + إعادة التخطيط | فشل اختبار = مفاجأة → خطة بديلة فورية |
| `nawah_goal` | goals.propose | تفكيك المهمة إلى أهداف فرعية "قابلة للتعلم/الوصول" |
| `nawah_memory` | memory (مفاجآت/مخططات/تفسيرات) | استرجاع تجارب مماثلة قبل |
| `nawah_evolve` | meta (DGM-lite) | تطوير إعدادات الوكيل بأرشيف أنساب + حارس objective-hacking |
| `nawah_bench` | bench_compare/transfer | قياس: هل التغيير فرق فعلاً؟ (مقارنة عمياء) |

التوصيل في `opencode.json`:
```json
{ "mcp": { "nawah": { "type": "local",
  "command": ["python", "-m", "nawah.mcp_server"] } },
  "permission": { "nawah_evolve": "ask" } }
```
**القوة**: الأدوات تصبح first-class — نفس بوابة الصلاحيات ونفس hooks الإضافات (موثق من الكود المصدري: "second-class in origin, first-class in treatment").
**العيب**: NAWAH-AGI رمزي — فهم الكود يبقى عند LLM؛ قيمته في **المستوى الفوقي**: التخطيط/التحقق/الذاكرة/التطور.

### C) إضافة (Plugin) للأذن الحية — حلقة التعلّم (أيام)
`.opencode/plugins/nawah.ts` يشترك في أحداث الجلسة (tool.execute، edit، نتائج bash):
- كل نجاح → `nawah_learn` (consolidation → مهارة جديدة في `.opencode/skills/`)
- كل فشل/مفاجأة → `nawah_memory` (تعلم + إعادة تخطيط في الجلسة التالية)
- يُغلق الحلقة: **استعمال → تعلّم → مهارة → إعادة استخدام** — وهذا بالضبط هدف NAWAH الأصلي.

### D) SDK — NAWAH-AGI كدمج يقود OpenCode (أسبوع+)
عبر `@opencode-ai/sdk` (أو `@opencode/client` في V2):
1. `session.create()` لكل مهمة → `session.prompt()` بخطة NAWAH (الوهم = محاولة، التنفيذ = جلسة).
2. `event.subscribe()` → مراقبة الأحداث → `nawah_replan` عند الانحراف (اختبارات حمراء).
3. مخرجات منظمة `json_schema` = مخرجات مُتحقَّقة (verification!) — يستخدمها NAWAH لتقييم النجاح ميكانيكيًا.
4. **الذروة**: DGM-lite يطوّر ملفات `.opencode/agents/*.md` (prompt, steps, permissions) — وكيل برمجي يُحسّن نفسه بنفسه بأرشيف أنساب وحارس anti-objective-hacking (نفس درس DGM: قِس على اختبار منفصل).

### E) المنتج المركّب "NAWAH for OpenCode" (الرؤية الكاملة)
```
المهمة → [D: SDK/الدمج: خطة NAWAH] → [B: MCP: أدوت الخطة/التحقق]
       → تنفيذ OpenCode (build/plan) → [C: Plugin: الأحداث → الذاكرة]
       → consolidation → [A: Skills: مهارة جديدة مُتحقَّقة]
       → [D: DGM-lite يطوّر الوكلاء] → ...
```

## 4) مصفوفة الجدوى

| التصميم | الجهد | الأثر | الجاهزية التقنية | الأولوية |
|---|---|---|---|---|
| A مهارات | ساعات | عالٍ فورًا | ✅ مفتوح (SKILL.md معيار) | **1** |
| B MCP | 2–4 أيام | عالٍ جدًا | ✅ SDK Python رسمي | **2** |
| C Plugin | 2–3 أيام | متوسط (حلقة التعلّم) | ✅ أحداث موثّقة | 3 |
| D SDK | أسبوع+ | عالٍ استراتيجيًا | ✅ API كامل | 4 |
| E مركّب | مراحل | تحويلي | يعتمد على A–D | الهدف |

## 5) التصميم الموصى به — تفصيل تنفيذي

**المرحلة 1 (اليوم)**: محوّل مهارات `nawah_skills_export.py` → `.opencode/skills/` — مكتبة NAWAH المُتحقَّقة تصبح مهارات OpenCode فورًا.
**المرحلة 2**: `nawah/mcp_server.py` (Python `mcp` SDK, stdio) بالأدوات السبع أعلاه + schemas صارمة + أذونات (`nawah_evolve: ask`).
**المرحلة 3**: plugin `nawah.ts` لالتقاط الأحداث + consolidation دوري.
**المرحلة 4**: `nawah/oc_driver.py` عبر SDK — تجارب DGM على وكلاء حقيقيين (تدريب/اختبار منفصلان — حارس objective-hacking إلزامي كما ثبت في مقاييسنا: 51.4=51.4 درس).

**التكامل مع النسخة الأساسية NAWAH**: صيغة مهارات NAWAH الحالية قريبة من Agent Skills (اسم/وصف/خطوات) — الـ adapter يضيف frontmatter الإلزامي فقط (`name` مطابق للمجلد `^[a-z0-9]+(-[a-z0-9]+)*$`، `description` ≤1024 حرفًا).

## 6) المخاطر والحدود — الصدق الإلزامي (كما في كل عملنا)

1. **مُراجَع**: ~~نموذج العالم لا يقرأ كودًا~~ — `nawah/codeworld.py` يقرأ الكود الحقيقي (AST) ويتنبأ بأثر التحريرات بدقة مُقاسة 100% مع النقل عبر إعادة التسمية. الادعاء المتبقي الصادق: القراءة المفتوحة المعنى وكتابة النصوص الجديدة تبقى لنماذج اللغة. من يدّعِ غير ذلك يكرر خطأ "AGI مصغر".
2. **التطور الذاتي لم يُثبت تعميمه** (51.4=51.4) — تطبيقه على وكلاء OpenCode يجب أن يبقى تجريبًا مُقاسًا لا وعود.
3. **تكلفة الدمج**: MCP يستهلك نافذة السياق (أدوات متاحة) — الحل: تحميل عند الطلب (lazy) كما تفعل catalogs المهارات.
4. **الإصدارات**: V2 ما زال يتغير (beta) — التثبيت على 1.18 المستقر + مراقبة تغييرات `@opencode/client`.
5. **الأمان**: كل أداة تمر ببوابة الصلاحيات — اضبط `permission` لكل أدوات `nawah_*` (evolve/learn = ask في البداية).

## 6-ب) التنفيذ — المُنجَز الآن (جاهز للاستعمال)

كل ما في القسم 5 مبني ومُختبر فعلاً:

```bash
# 1) التوصيل الفوري (مضمَّن في opencode.json):
python3 -m nawah.mcp_server          # خادم MCP — 9 أدوات
# 2) مهارات Agent Skills (تُكتب في .opencode/skills/):
python3 -m nawah.oc_skills .opencode/skills
# 3) إطعام ملاحظة يدوية (تستعملها الإضافة):
python3 -m nawah.oc_observe --action tool:bash --before ran:bash --after ran:bash,result:ok
# 4) قيادة OpenCode من NAWAH (يتطلب `opencode serve`):
python3 -m nawah.oc_driver --task "..." --goal "tests:passing" --probe "python3 probe.py"
```

الاختبارات: `tests/test_oc_bridge.py` (9 اختبارات: بروتوكول MCP كامل على
عمليات حقيقية، صيغة SKILL.md مقابل المواصفة، حلقة السائق ضد خادم OpenCode
وهمي). مع النواة: **98/98** + ruff نظيف.

## 7) خلاصة الحكم

> **نعم — الربط ممكن تقنيًا بالكامل، وبلهجة مثالية**: OpenCode صُمّم للتوسعة عبر MCP/Skills/Plugins/SDK، وNAWAH صُمّم أصلًا كـ"طبقة مهارات فوق أي نموذج" — والالتقاء الطبيعي: **NAWAH = طبقة الذاكرة والمهارات والتحقق لوكيل OpenCode**. الأسرع: تصدير المهارات (ساعات). الأعمق: MCP + SDK مع DGM-lite يطوّر الوكلاء — وعليه يبقى الحارس الوحيد: قياس كل تحسن على اختبار منفصل بالأرقام.

## 8) المصادر (المرجعية)

- OpenCode الرسمي: https://opencode.ai/docs/ (mcp-servers, skills, config, tools, agents, sdk, server) — تحققت من: MCP رسمي، SKILL.md بحقول frontmatter الخمسة، SDK المولَّد من OpenAPI 3.1، خادم 127.0.0.1:4096.
- المستودع النشط: github.com/anomalyco/opencode (MIT) — النسخة Go القديمة متوقفة منذ سبتمبر 2025.
- معمارية الأدوات (first-class MCP): درس opencode-visual-guide 46 — الأدوات الخارجية تمر بنفس سجل الأدوات وبوابة الصلاحيات.
- Agent Skills المعيار المفتوح: agentskills.io/specification — هيكل المجلد + progressive loading.
- V2 (أكتوبر 2026): anoma.ly/notes/opencode-2-0 + مراجعات kingy.ai/aiagentslist — plugin API جديد، @opencode/client.
- أمثلة تكامل عملية: prviders/opencode-sdk من promptfoo، datadog opencode-plugin، opencode-primer (أمثلة agents/skills/plugins/MCP).
