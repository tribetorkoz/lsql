"""
Export NAWAH knowledge as OpenCode Agent Skills (SKILL.md).

OpenCode discovers .opencode/skills/<name>/SKILL.md automatically and
advertises each skill's description to the model on demand — so this
exporter is what turns a learned, verified skill library into behavior
the coding agent actually exhibits.

Three sources:
  1. meta-skills  — how to USE the nawah_* MCP tools (the workflow)
  2. SkillStore   — the verified skill library (nawah/store.py)
  3. operators    — lifted world-model schemas as "when/what" skills

Frontmatter rules enforced (Agent Skills spec + OpenCode):
  name: 1-64 chars, ^[a-z0-9]+(-[a-z0-9]+)*$, matches directory
  description: 1-1024 chars
"""

from __future__ import annotations

import re
from pathlib import Path

_NAME_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")

META_SKILLS = [
    {
        "name": "nawah-plan-before-code",
        "description": (
            "Use BEFORE multi-step coding tasks. Teaches the nawah_plan "
            "workflow: set the current state as facts, define the goal "
            "as facts, get an ordered action plan from the NAWAH-AGI "
            "world model, then execute step by step. Cuts wasted edits."
        ),
        "body": """# Plan before code with NAWAH-AGI

## When to use
Multi-step tasks: new features, refactors across files, bug fixes with
several hypotheses, anything where you would otherwise improvise.

## Procedure
1. Describe the CURRENT world as facts (MCP tool `nawah_state_set`):
   `["tests:failing", "file:auth.py:missing", "deps:installed"]`
2. Describe the GOAL as facts: `["tests:passing", "file:auth.py:exists"]`
3. Call `nawah_plan` with that goal. It returns an ordered action list
   learned from experience (or from the lifted operator model).
4. Execute the plan actions in order. After each meaningful action,
   call `nawah_observe` with (action, before, after) facts — this is
   how the model stays honest.
5. If reality diverges (a test fails), call `nawah_replan` with the
   goal and the failed action — do NOT keep improvising.

## Why
A blind search through edits is the 25% branch. The planned branch
scores 100% at a quarter of the steps (measured: bench_compare).
""",
    },
    {
        "name": "nawah-replan-on-surprise",
        "description": (
            "Use when reality contradicts expectations: a test that "
            "should pass fails, an edit conflicts, a command errors. "
            "Teaches nawah_replan + nawah_observe: record the surprise, "
            "refine the model, get a fresh plan instead of looping."
        ),
        "body": """# Replan on surprise

## When to use
Any moment the world said "no": red tests, build errors, unexpected
diffs, permission denials.

## Procedure
1. `nawah_observe` the failed action: before facts = what you expected
   to hold, after facts = what actually holds. `surprise: true` means
   the model just learned something.
2. `nawah_replan` with the same goal and `failed_action`.
3. Follow the new plan. Two failures on the same action = stop and
   ask the user; the model has no theory for this situation.

## Why
The world model refines lifted operators on every surprise. One
observation of failure is information; three in a row is a question.
""",
    },
    {
        "name": "nawah-verify-and-consolidate",
        "description": (
            "Use AFTER completing a task. Teaches the NAWAH close-out: "
            "verify the goal facts actually hold, then let NAWAH "
            "consolidate the episode into reusable skill knowledge."
        ),
        "body": """# Verify and consolidate

## When to use
Task complete, or a meaningful milestone reached.

## Procedure
1. Re-derive the goal facts (run the checks, read the files) and call
   `nawah_state_set` with the verified facts.
2. `nawah_plan` with the goal: `solved_at_start: true` is the
   machine-checked claim of completion.
3. Record the episode outcomes via `nawah_observe` for any step whose
   result was not already logged.

## Why
NAWAH's claim is that experience should survive. An unverified "done"
is a rumor; a verified one is a skill.
""",
    },
    {
        "name": "nawah-self-improve",
        "description": (
            "Use when the task was hard and the agent wants to improve "
            "its own planning. Runs nawah_evolve (DGM-lite) on the "
            "session's tasks and reports evolved planning genes with "
            "lineage. Sparingly — it is a measured improvement step, "
            "not a magic word."
        ),
        "body": """# Self-improve (DGM-lite)

## When to use
End of a hard session, or when plans keep failing.

## Procedure
1. `nawah_evolve` with `generations: 4-8`.
2. Read `best_genes` and `lineage`. If `curve` rises, the evolved
   planner genes beat the seed on this session's tasks.
3. Report the numbers. Never claim improvement without the curve.

## Why
Self-improvement that is not measured is wishful thinking. The DGM
lesson (51.4 = 51.4): improvements must survive a held-out check.
""",
    },
]


def _slug(text: str, fallback: str = "skill") -> str:
    s = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    s = re.sub(r"-{2,}", "-", s)
    if not s or not _NAME_RE.match(s):
        s = fallback
    return s[:64]


def skill_md(
    name: str, description: str, body: str, metadata: dict | None = None
) -> str:
    desc = " ".join(description.split())[:1024]
    lines = ["---", f"name: {name}", f"description: {desc}"]
    if metadata:
        lines.append("metadata:")
        for k, v in metadata.items():
            lines.append(f"  {k}: {v}")
    lines.append("---")
    return "\n".join(lines) + "\n\n" + body.strip() + "\n"


def from_store(store) -> list[dict]:
    """Adapt the verified SkillStore library to Agent-Skills entries."""
    out = []
    for sk in store.skills():
        name = _slug(str(sk.id), fallback="skill")
        body_text = (sk.body or "").strip()
        when = ""
        m = re.search(
            r"##\s*When to use\s*\n(.*?)(?:\n##|\Z)", body_text, re.S
        )
        if m:
            when = m.group(1).strip()
        first_line = body_text.split("\n")[0].lstrip("# ").strip()
        desc_src = when or first_line or f"Verified NAWAH skill {name}"
        body = f"# {sk.family} — {sk.id}\n\n{body_text}\n"
        out.append(
            {
                "name": name,
                "description": desc_src,
                "body": body,
                "metadata": {
                    "source": "nawah-skill-store",
                    "strength": sk.strength,
                    "wins": sk.wins,
                    "sound": sk.is_sound,
                },
            }
        )
    return out


def from_operators(model) -> list[dict]:
    """Each lifted operator schema becomes a 'when/what' skill."""
    out = []
    for key, op in sorted(model.ops.items()):
        if not op.add and not op.dele:
            continue
        slug = (
            key.replace("(", "-")
            .replace(")", "")
            .replace("?a", "arg")
            .replace(",", "-")
        )
        name = _slug(f"nawah-op-{slug}")
        pre = ", ".join(sorted(str(a) for a in op.pre)) or "(none)"
        add = ", ".join(sorted(str(a) for a in op.add)) or "(none)"
        dele = ", ".join(sorted(str(a) for a in op.dele)) or "(none)"
        desc = (
            f"Learned operator {key}: when {pre} holds, apply this "
            f"action to add [{add}] and remove [{dele}]. "
            f"Observed {op.n_obs} times."
        )
        body = (
            f"# Operator {key}\n\n## When to use\nState matches: {pre}\n\n"
            f"## Effect\nadds: {add}\nremoves: {dele}\n"
        )
        out.append(
            {
                "name": name,
                "description": desc,
                "body": body,
                "metadata": {
                    "source": "nawah-world-model",
                    "observations": op.n_obs,
                },
            }
        )
    return out


def export_skills(
    out_dir: str | Path, store=None, model=None, include_meta: bool = True
) -> list[str]:
    """Write SKILL.md files; returns the skill names written."""
    out = Path(out_dir)
    entries = []
    if include_meta:
        entries.extend(META_SKILLS)
    if store is not None:
        entries.extend(from_store(store))
    if model is not None:
        entries.extend(from_operators(model))
    written = []
    for e in entries:
        name = e["name"]
        assert _NAME_RE.match(name) and len(name) <= 64, name
        assert 1 <= len(" ".join(e["description"].split())) <= 1024
        d = out / name
        d.mkdir(parents=True, exist_ok=True)
        (d / "SKILL.md").write_text(
            skill_md(name, e["description"], e["body"], e.get("metadata")),
            encoding="utf-8",
        )
        written.append(name)
    return written


def main() -> int:
    import argparse

    ap = argparse.ArgumentParser(
        description="Export NAWAH skills as OpenCode Agent Skills"
    )
    ap.add_argument("out", nargs="?", default=".opencode/skills")
    ap.add_argument("--store", help="SkillStore JSON to include")
    args = ap.parse_args()
    store = None
    if args.store:
        from .store import SkillStore

        store = SkillStore.load(args.store)
    names = export_skills(args.out, store=store)
    print(f"exported {len(names)} skills -> {args.out}")
    for n in names:
        print(f"  - {n}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
