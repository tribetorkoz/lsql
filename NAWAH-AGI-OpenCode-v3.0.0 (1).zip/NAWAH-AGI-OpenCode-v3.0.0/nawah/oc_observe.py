"""
Feed one observed transition into the shared NAWAH store.

Called by the OpenCode plugin (.opencode/plugins/nawah.ts) after every
meaningful event. Appends to .nawah/obs.jsonl — the same log the MCP
server can replay — so knowledge survives between sessions.

    python3 -m nawah.oc_observe --action tool:bash \
        --before ran:bash --after ran:bash,result:ok
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def feed(
    action: str,
    before: list[str],
    after: list[str],
    store: str | Path = ".nawah/obs.jsonl",
) -> dict:
    p = Path(store)
    p.parent.mkdir(parents=True, exist_ok=True)
    rec = {"action": action, "before": before, "after": after}
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return rec


def load_observations(store: str | Path = ".nawah/obs.jsonl") -> list[dict]:
    p = Path(store)
    if not p.exists():
        return []
    out = []
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            out.append(json.loads(line))
    return out


def replay(obs: list[dict]):
    """Rebuild a Brain from the observation log."""
    from .mcp_server import Brain

    b = Brain()
    for r in obs:
        b.observe(r["action"], r["before"], r["after"])
    return b


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--action", required=True)
    ap.add_argument("--before", default="", help="comma-separated facts")
    ap.add_argument("--after", default="", help="comma-separated facts")
    ap.add_argument("--store", default=".nawah/obs.jsonl")
    args = ap.parse_args()
    before = [f for f in args.before.split(",") if f]
    after = [f for f in args.after.split(",") if f]
    rec = feed(args.action, before, after, args.store)
    print(json.dumps(rec, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
