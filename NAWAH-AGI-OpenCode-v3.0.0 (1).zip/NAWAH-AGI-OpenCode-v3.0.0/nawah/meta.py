"""
Meta — the agent improves its OWN policy, under empirical validation.

This is the Darwin Goedel Machine idea (Sakana/UBC 2025, ICLR 2026)
scaled honestly to this codebase:

    * a POLICY GENOME is the set of decisions the agent makes about
      itself: search budget, replans allowed, goal-proposal rule,
      exploration knob, when to consolidate. DGM rewrites code; we
      evolve the policy layer — same shape of claim, safer substrate.
    * an ARCHIVE of validated genomes, with lineage (parent ids).
      Open-ended exploration keeps UNUSUAL successful genomes, not
      only the current best (the DGM ablation shows this matters).
    * every mutation is accepted only by FUTURE performance on a held
      validation suite — empirical evidence, never optimism. DGM's own
      documentation warns about objective-hacking; the guard here is
      that evolution is scored on train-goals and REPORTED on disjoint
      test-goals, and the two are never mixed.

A genome is plain JSON-able data, so a winning policy can be exported
next to the skill library.
"""

from __future__ import annotations

import copy
import random
from dataclasses import dataclass, field

# The knobs the agent is allowed to change about itself.
GENOME_SPACE = {
    # planner
    "max_replans": (1, 6),
    "max_explore": (2, 14),
    "search_nodes": (500, 8000),
    # goal curriculum
    "goal_rule": ["learnability", "progress", "novelty"],
    # self-practice: how many free-play goals per evaluation round
    "free_play": (0, 8),
}


@dataclass
class Genome:
    genes: dict
    parent: str = ""
    gid: str = ""
    score: float = float("-inf")
    n_eval: int = 0

    def fingerprint(self) -> str:
        return "|".join(f"{k}={self.genes[k]}" for k in sorted(self.genes))


def random_genome(rng: random.Random, gid: str = "g0") -> Genome:
    genes = {}
    for k, space in GENOME_SPACE.items():
        if isinstance(space, list):
            genes[k] = rng.choice(space)
        else:
            lo, hi = space
            genes[k] = (
                rng.randint(lo, hi)
                if isinstance(lo, int)
                else rng.uniform(lo, hi)
            )
    return Genome(genes, gid=gid)


def mutate(parent: Genome, rng: random.Random, gid: str) -> Genome:
    genes = copy.deepcopy(parent.genes)
    knobs = list(GENOME_SPACE)
    k = rng.choice(knobs)
    space = GENOME_SPACE[k]
    if isinstance(space, list):
        genes[k] = rng.choice([x for x in space if x != genes[k]] or space)
    else:
        lo, hi = space
        delta = max(1, (hi - lo) // 5)
        v = genes[k] + rng.randint(-delta, delta)
        genes[k] = int(min(hi, max(lo, v)))
    return Genome(genes, parent=parent.gid, gid=gid)


@dataclass
class Archive:
    """Lineage tree of validated genomes (DGM's core data structure)."""

    members: list = field(default_factory=list)
    max_size: int = 40

    def add(self, g: Genome):
        self.members.append(g)
        # keep the archive BOUNDED but diverse: drop the worst-score
        # duplicate fingerprint first, never a unique design.
        if len(self.members) > self.max_size:
            seen: dict = {}
            for m in self.members:
                fp = m.fingerprint()
                if fp in seen and m.score < seen[fp].score:
                    seen[fp] = m
            # prefer dropping low-score duplicates
            dups = {}
            for m in self.members:
                dups.setdefault(m.fingerprint(), []).append(m)
            drop = None
            for _fp, group in dups.items():
                if len(group) > 1:
                    drop = min(group, key=lambda x: x.score)
                    break
            if drop is None:
                drop = min(self.members, key=lambda x: x.score)
            self.members.remove(drop)

    def sample_parent(self, rng: random.Random) -> Genome:
        # bias toward better genomes but keep exploration (softmax-free:
        # top half uniformly — simple, and matches "sample from archive")
        ranked = sorted(self.members, key=lambda g: -g.score)
        pool = ranked[: max(1, len(ranked) // 2)] or ranked
        return rng.choice(pool)

    def best(self) -> Genome | None:
        if not self.members:
            return None
        return max(self.members, key=lambda g: g.score)

    def lineage(self, g: Genome) -> list:
        by = {m.gid: m for m in self.members}
        chain = [g.gid]
        cur = g
        while cur.parent and cur.parent in by:
            chain.append(cur.parent)
            cur = by[cur.parent]
        return list(reversed(chain))


class MetaEvolver:
    """
    One DGM-style loop step: sample a parent, mutate, EVALUATE (the
    caller supplies a scoring function that runs real goals), archive
    the child, repeat. The score is empirical or it is nothing.
    """

    NEUTRAL = {
        "max_replans": 3,
        "max_explore": 8,
        "search_nodes": 4000,
        "goal_rule": "learnability",
        "free_play": 4,
    }

    def __init__(self, seed: int = 0, archive: Archive | None = None):
        self.rng = random.Random(f"meta:{seed}")
        self.archive = archive or Archive()
        self.gen = 0
        if not self.archive.members:
            # the seed genome is a FIXED neutral policy, not a lucky draw:
            # whatever evolution finds, it must earn against this.
            self.archive.add(Genome(dict(self.NEUTRAL), gid="g0"))

    def propose_child(self) -> Genome:
        parent = self.archive.sample_parent(self.rng)
        self.gen += 1
        return mutate(parent, self.rng, gid=f"g{self.gen}")

    def step(self, evaluate_fn) -> Genome:
        """evaluate_fn(genome) -> float (higher is better). One cycle."""
        child = self.propose_child()
        child.score = evaluate_fn(child)
        child.n_eval = 1
        self.archive.add(child)
        return child

    def run(self, evaluate_fn, generations: int) -> list:
        history = []
        for _ in range(generations):
            c = self.step(evaluate_fn)
            history.append((c.gid, c.score, self.archive.best().score))
        return history
