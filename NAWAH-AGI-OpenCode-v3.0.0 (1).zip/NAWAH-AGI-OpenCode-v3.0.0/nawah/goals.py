"""
Goals — the agent invents its own curriculum.

This is the "automatic curriculum" of Voyager (2023) made measurable,
with the learnability reward of Absolute Zero Reasoner (2025) and the
learnability FILTER of CIG (2026, to dodge the noisy-TV trap):

    learnability(goal) = 1 - p_success(goal)   (AZR: practise what you
                                                are half right about)
    x (1 - already_true)                     (not trivial)
    x reachable(model, state, goal)          (not impossible -- the
                                              model's reachability
                                              estimate is the filter)

Goals are generated from the WORLD'S OWN vocabulary (items held, rooms
reached, doors unlocked), not from a fixed task list — which is what
makes free play open-ended rather than a shuffled syllabus.
"""

from __future__ import annotations

from dataclasses import dataclass

from .memory import goal_fingerprint
from .planner import plan
from .worlds import atom


def candidate_goals(state: frozenset, level, max_goals: int = 24) -> list:
    """Generate goal candidates grounded in this world: hold an item,
    reach a room, unlock a door. Every candidate is a small atom set."""
    cands = []
    here = next(
        (a[2] for a in state if a[0] == "at" and a[1] == "agent"), None
    )
    for item in level.items:
        cands.append(frozenset({atom("has", "agent", item)}))
    for room in level.rooms:
        if room != here:
            cands.append(frozenset({atom("at", "agent", room)}))
    for door in level.locks:
        cands.append(frozenset({atom("unlocked", door)}))
    # compound goals: item + place (the classic harder-than-its-parts)
    items = list(level.items)
    if len(items) >= 1 and level.rooms:
        cands.append(
            frozenset(
                {
                    atom("has", "agent", items[0]),
                    atom("at", "agent", level.rooms[-1]),
                }
            )
        )
    return cands[:max_goals]


@dataclass
class Proposal:
    goal: frozenset
    learnability: float
    reachable: bool
    reason: str = ""


@dataclass
class GoalProposer:
    """
    Proposes what to practise next from where the agent actually is.

    rule:
      'learnability'  AZR: maximise 1 - p(success)  (in the productive
                      middle — hard-but-possible goals win)
      'progress'      curiosity: maximise learning progress of the MODEL
                      in the states this goal would visit (3M-Progress /
                      gamma-Progress family)
      'novelty'       least-practised goal shape (coverage play)
    """

    memory: object
    model: object
    rule: str = "learnability"
    rng: object = None

    def propose(self, state, level, afford_fn) -> Proposal | None:
        best = None
        for g in candidate_goals(state, level):
            if g <= state:
                continue  # trivial now
            reachable = (
                plan(self.model, state, g, afford_fn, max_nodes=800)
                is not None
            )
            p = self.memory.p_success(g)
            learnability = (1.0 - p) * (1.0 if reachable else 0.2)
            if self.rule == "progress":
                score = self.model.learning_progress() * (0.5 + learnability)
            elif self.rule == "novelty":
                _s, n = self.memory.goal_record[goal_fingerprint(g)]
                score = 1.0 / (1.0 + n) + 0.3 * learnability
            else:
                score = learnability
            prop = Proposal(g, score, reachable)
            if best is None or prop.learnability > best.learnability:
                best = prop
        return best

    def survey(self, state, level, afford_fn) -> list:
        """All proposals with scores — the report a curious agent keeps."""
        out = []
        for g in candidate_goals(state, level):
            reachable = (
                plan(self.model, state, g, afford_fn, max_nodes=400)
                is not None
            )
            out.append(Proposal(g, self.memory.p_success(g), reachable))
        return sorted(out, key=lambda p: -p.learnability)
