"""
WorldModel — learn the dynamics as lifted OPERATORS from executed
transitions, and know how much you do not know.

The research lineage, briefly (see AGI.md for the full map):
    * skills must be COMPOSABLE OPERATORS with preconditions/effects,
      not just text        (CUA-Skill 2026; STRIPS/HTN tradition)
    * the model learns them from interaction, plans inside them
      (Curiosity-Driven Imagination 2025; HWM 2026)
    * prediction error = surprise; improvement = learning progress;
      both drive what to practise next (3M-Progress, gamma-Progress,
      CIG's learnability filter 2025-26 — avoid the "noisy TV" trap)

Induction rule (the core of the module):
    1. one executed transition (s, a, s') is LIFTED into a schema by
       renaming every entity that is not an action argument to a
       variable, numbered by first occurrence — entities in different
       levels have different names, so this is what makes transfer
       across levels possible at all;
    2. preconditions := lifted prestate atoms (minus static map facts),
       INTERSECTED across observations of the same action schema
       (least-general generalisation) — the intersection, not a
       single-observation heuristic, is what drops the noise;
    3. effects := intersection of lifted add-sets and del-sets. If two
       observations disagree the operator is marked unreliable and the
       planner must verify in the environment (honest failure).
"""

from __future__ import annotations

from dataclasses import dataclass, field


def _lift_atom(a: tuple, arg_vars: dict, varmap: dict) -> tuple:
    out = [a[0]]
    for x in a[1:]:
        if x in arg_vars:
            out.append(arg_vars[x])
        else:
            if x not in varmap:
                varmap[x] = f"?V{len(varmap)}"
            out.append(varmap[x])
    return tuple(out)


def lift_transition(action: str, s: frozenset, s2: frozenset):
    """(s, a, s') -> (schema_name, pre_atoms, add_atoms, del_atoms) lifted."""
    name, _, argstr = action.partition(":")
    args = tuple(argstr.split(",")) if argstr else ()
    arg_vars = {a: f"?A{i}" for i, a in enumerate(args)}
    add = s2 - s
    dele = s - s2
    # variables are introduced by walking effects first, then the action,
    # then candidate preconditions — order defines canonical numbering
    varmap: dict = {}
    static_preds = {"adj", "needs", "at_room_of"}
    pre_constants = {x for a in s if a[0] not in static_preds for x in a[1:]}

    def lift_effect(atom: tuple) -> tuple:
        """Effect lifting: action arguments become ?A vars, constants
        the prestate shares become ?V vars, and anything else stays a
        CONSTANT — it is a value the action introduces (like a key the
        operator turns to 'on'). Var-lifting those produced unbound
        ?V variables in effects and predicted garbage states."""
        out = [atom[0]]
        for x in atom[1:]:
            if x in arg_vars:
                out.append(arg_vars[x])
            elif x in pre_constants:
                if x not in varmap:
                    varmap[x] = f"?V{len(varmap)}"
                out.append(varmap[x])
            else:
                out.append(x)
        return tuple(out)

    add_l = [lift_effect(a) for a in sorted(add)]
    del_l = [lift_effect(a) for a in sorted(dele)]
    pre_l = []
    for a in sorted(s):
        if a[0] in static_preds:
            continue  # map facts are context, never action preconditions
        pre_l.append(_lift_atom(a, arg_vars, varmap))
    schema = name + "(" + ",".join(f"?A{i}" for i in range(len(args))) + ")"
    return schema, frozenset(pre_l), frozenset(add_l), frozenset(del_l)


@dataclass
class Operator:
    schema: str
    pre: set = field(default_factory=set)
    add: set = field(default_factory=set)
    dele: set = field(default_factory=set)
    n_obs: int = 0
    reliable: bool = True
    # exact recall of grounded transitions seen (fast path)
    seen: dict = field(default_factory=dict)

    def observe(self, action: str, s: frozenset, s2: frozenset):
        self.seen[action] = self.seen.get(action, set()) | {(s, s2)}
        _schema, pre, add, dele = lift_transition(action, s, s2)
        self.n_obs += 1
        if self.n_obs == 1:
            self.pre, self.add, self.dele = set(pre), set(add), set(dele)
        else:
            self.pre &= set(pre)
            self.add &= set(add)
            self.dele &= set(dele)
            if not self.add and not self.dele:
                self.reliable = False

    def grounded_on(self, action: str) -> tuple:
        """Substitution ?A{i} -> action argument i."""
        _name, _, argstr = action.partition(":")
        args = tuple(argstr.split(",")) if argstr else ()
        return {f"?A{i}": a for i, a in enumerate(args)}


def _match(atom_l: tuple, atom_g: tuple, bind: dict) -> dict | None:
    if atom_l[0] != atom_g[0] or len(atom_l) != len(atom_g):
        return None
    b = dict(bind)
    for lv, gv in zip(atom_l[1:], atom_g[1:], strict=True):
        if lv.startswith("?"):
            if lv in b:
                if b[lv] != gv:
                    return None
            else:
                b[lv] = gv
        elif lv != gv:
            return None
    return b


def _match_set(patterns, atoms, bind) -> dict | None:
    """Subgraph match of lifted patterns into ground atoms (small states)."""
    patterns = list(patterns)
    if not patterns:
        return bind
    p, rest = patterns[0], patterns[1:]
    for g in atoms:
        b = _match(p, g, bind)
        if b is not None:
            got = _match_set(rest, atoms, b)
            if got is not None:
                return got
    return None


class WorldModel:
    """Learns action schemas; predicts; reports surprise & progress."""

    def __init__(self):
        self.ops: dict[str, Operator] = {}
        self.surprise_log: list[float] = []
        self.state_visits: dict = {}
        self._prev_acc: float | None = None

    # ── learning ─────────────────────────────────────────────
    def observe(self, action: str, s: frozenset, s2: frozenset) -> bool:
        """Record one executed transition. Returns True if it was predicted
        correctly BEFORE learning it (i.e. zero surprise)."""
        pred = self.predict(s, action)
        surprise = 0.0 if pred == s2 else 1.0
        self.surprise_log.append(surprise)
        name, _, argstr = action.partition(":")
        nargs = len(argstr.split(",")) if argstr else 0
        key = name + "(" + ",".join(f"?A{i}" for i in range(nargs)) + ")"
        op = self.ops.setdefault(key, Operator(key))
        op.observe(action, s, s2)
        self.state_visits[s] = self.state_visits.get(s, 0) + 1
        return surprise == 0.0

    # ── prediction ───────────────────────────────────────────
    def predict(self, s: frozenset, action: str) -> frozenset | None:
        """Predict next state using the learned model. None = I don't know.

        Fast path: exact grounded recall. General path: apply the lifted
        operator by matching its preconditions into s.
        """
        name, _, argstr = action.partition(":")
        nargs = len(argstr.split(",")) if argstr else 0
        key = name + "(" + ",".join(f"?A{i}" for i in range(nargs)) + ")"
        op = self.ops.get(key)
        if op is None:
            return None
        for s_old, s2_old in op.seen.get(action, ()):
            if s_old == s:
                return s2_old
        if not op.reliable:
            return None
        bind0 = op.grounded_on(action)
        bind = _match_set(op.pre, s, bind0)
        if bind is None:
            return None
        out = set(s)
        for atom in op.dele:
            out.discard(_sub(atom, bind))
        for atom in op.add:
            out.add(_sub(atom, bind))
        return frozenset(out)

    def applicable_learned(self, s: frozenset, affordances) -> list:
        """Of the env affordances, which ones the model believes it can do
        and predict. Used to keep planning inside imagination."""
        return [a for a in affordances if self.predict(s, a) is not None]

    def novelty(self, s: frozenset, action: str) -> float:
        """How unexplored is this action here? 1.0 = never tried this
        schema anywhere; 0.0 = this exact transition already recalled.
        The exploration signal — curiosity is 'act where the model is
        silent' (CIG's novelty axis), not 'chase surprise' (noisy-TV)."""
        name, _, argstr = action.partition(":")
        nargs = len(argstr.split(",")) if argstr else 0
        key = name + "(" + ",".join(f"?A{i}" for i in range(nargs)) + ")"
        if action.startswith("drop:"):
            return 0.0  # dropping only undoes take; it carries no
            # discovery value, and a curious agent that treats it as
            # novel drops its keys before reaching any door
        op = self.ops.get(key)
        if op is None:
            return 3.0  # never tried this KIND of action anywhere
        if any(s_old == s for s_old, _s2 in op.seen.get(action, ())):
            return 0.0
        return 0.25  # unseen (state, action) pair: flat, so 'drop once
        # in a new place' cannot out-shout 'walk into the unknown'

    # ── metacognition (the curiosity signals) ────────────────
    def mean_surprise(self, last: int = 50) -> float:
        w = self.surprise_log[-last:]
        return sum(w) / len(w) if w else 1.0

    def learning_progress(self, last: int = 25) -> float:
        """gamma-Progress style: improvement in prediction success over the
        recent window (positive = still learning here)."""
        w = self.surprise_log
        if len(w) < 2 * last:
            return 1.0  # early days: everything is progress
        old = sum(w[-2 * last : -last]) / last
        new = sum(w[-last:]) / last
        return max(0.0, old - new)

    def coverage(self) -> str:
        return (
            f"{len(self.ops)} schemas, "
            f"{sum(op.n_obs for op in self.ops.values())} transitions, "
            f"surprise={self.mean_surprise():.2f}"
        )


def _sub(atom_l: tuple, bind: dict) -> tuple:
    return tuple(bind.get(x, x) for x in atom_l)
