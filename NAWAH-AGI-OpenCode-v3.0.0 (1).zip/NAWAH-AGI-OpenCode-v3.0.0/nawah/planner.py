"""
Planner — plan inside the learned world model, execute outside it.

The architecture follows the 2025-26 hierarchical-planning results
(HTN / GoalAct / HiPlan / HWM): search a plan in imagination, execute it
step-by-step against the real environment, and REPLAN the moment
imagination and reality disagree (prediction error is the trigger — not
a fixed schedule). Local replanning on the smallest broken subtree is
the ideal; here that subtree is simply "the remaining suffix".

The search is greedy best-first over predicted states:
    h(s) = number of goal atoms not yet true   (goal-count heuristic)
Plans are lists of grounded actions. Nothing in `plan()` touches the
environment; `OnlinePlanner.solve` is the only thing that does.
"""

from __future__ import annotations

import heapq
import random
from dataclasses import dataclass, field


@dataclass
class Plan:
    actions: list
    goal: frozenset
    predicted: list = field(default_factory=list)  # predicted states along it
    explored: int = 0
    from_cache: bool = False


def _relevant(state: frozenset, goal: frozenset) -> tuple:
    """Fingerprint of the facts a plan actually depends on: goal atoms
    plus same-predicate atoms (preconditions care about the predicate's
    world, not the whole state)."""
    preds = {a[0] for a in goal}
    rel = tuple(sorted(a for a in state if a[0] in preds))
    return rel


class PlanCache:
    """
    Case-based plan reuse: a solved (state, goal) pair is an asset.
    The cache keys on the goal plus only the facts a plan depends on,
    so a plan made in one room transfers to a renamed twin — which is
    exactly the operator-lifting promise, now at the plan level.
    """

    def __init__(self):
        self._plans: dict[tuple, list] = {}
        self.hits = 0
        self.misses = 0

    def key(self, state: frozenset, goal: frozenset) -> tuple:
        return (tuple(sorted(goal)), _relevant(state, goal))

    def get(self, state: frozenset, goal: frozenset):
        k = self.key(state, goal)
        if k in self._plans:
            self.hits += 1
            return list(self._plans[k])
        self.misses += 1
        return None

    def put(self, state: frozenset, goal: frozenset, actions: list) -> None:
        self._plans[self.key(state, goal)] = list(actions)

    def invalidate_goal(self, goal: frozenset) -> int:
        g = tuple(sorted(goal))
        drop = [k for k in self._plans if k[0] == g]
        for k in drop:
            del self._plans[k]
        return len(drop)

    def __len__(self) -> int:
        return len(self._plans)


def plan_hierarchical(
    model,
    start: frozenset,
    goal: frozenset,
    afford_fn,
    max_nodes: int = 4000,
    h_fn=None,
    cache: PlanCache | None = None,
) -> Plan | None:
    """
    Decompose a multi-fact goal into landmark subgoals and solve them in
    sequence (greedy order: cheapest reachable landmark first), with a
    plan cache between calls. A goal-count search over k independent
    facts is exponential; stacked single-landmark searches are not.
    Falls back to plain plan() for single-fact goals.
    """
    if goal <= start:
        return Plan([], goal, [start], 0)
    if cache is not None:
        hit = cache.get(start, goal)
        if hit is not None:
            s = start
            ok = True
            for a in hit:
                s2 = model.predict(s, a)
                if s2 is None:
                    ok = False
                    break
                s = s2
            if ok and goal <= s:
                return Plan(hit, goal, [start], 0, from_cache=True)
    todo = sorted(goal - start)
    if len(todo) <= 1:
        pl = plan(
            model, start, goal, afford_fn, max_nodes=max_nodes, h_fn=h_fn
        )
        if pl and cache is not None:
            cache.put(start, goal, pl.actions)
        return pl
    state = start
    actions: list = []
    preds: list = [start]
    # greedy landmark order: try each remaining fact from the current
    # state; first one that yields a plan anchors the sequence
    while todo:
        advanced = False
        for i, atom in enumerate(todo):
            sub = frozenset({atom})
            pl = plan(
                model, state, sub, afford_fn, max_nodes=max_nodes, h_fn=h_fn
            )
            if pl is None:
                continue
            actions.extend(pl.actions)
            preds.extend(pl.predicted[1:])
            state = preds[-1]
            todo.pop(i)
            advanced = True
            break
        if not advanced:
            # stubborn residue: one joint shot at whatever is left
            pl = plan(
                model,
                state,
                frozenset(todo),
                afford_fn,
                max_nodes=max_nodes,
                h_fn=h_fn,
            )
            if pl is None:
                return None
            actions.extend(pl.actions)
            preds.extend(pl.predicted[1:])
            break
    out = Plan(actions, goal, preds, 0)
    if cache is not None:
        cache.put(start, goal, out.actions)
    return out


def _h(state: frozenset, goal: frozenset) -> int:
    return len(goal - state)


def plan(
    model,
    start: frozenset,
    goal: frozenset,
    afford_fn,
    max_nodes: int = 4000,
    h_fn=None,
) -> Plan | None:
    """
    Greedy best-first search over the LEARNED model.

    afford_fn(state) -> grounded actions the agent could try here (its own
    affordance knowledge — a robot knows its own motors). Successors come
    from model.predict; actions the model cannot predict are not planned
    through (an honest planner does not invent physics).
    """
    if goal <= start:
        return Plan([], goal, [start], 0)
    hh = h_fn or _h
    open_h = [(hh(start, goal), 0, id(start), start, [])]
    best = {start: hh(start, goal)}
    came: dict = {}
    explored = 0
    while open_h and explored < max_nodes:
        _f, _g, _uid, s, path = heapq.heappop(open_h)
        explored += 1
        for a in afford_fn(s):
            s2 = model.predict(s, a)
            if s2 is None:
                continue
            if s2 in came or s2 == start:
                continue
            came[s2] = (s, a)
            p2 = [*path, a]
            if goal <= s2:
                traj = [s2]
                cur = s2
                while cur != start:
                    cur, _a = came[cur]
                    traj.append(cur)
                return Plan(p2, goal, list(reversed(traj)), explored)
            h = hh(s2, goal)
            if h < best.get(s2, 1 << 30):
                best[s2] = h
                heapq.heappush(open_h, (h + len(p2), len(p2), id(s2), s2, p2))
    return None


@dataclass
class SolveLog:
    plans: int = 0
    surprises: int = 0
    steps: int = 0
    achieved: bool = False
    events: list = field(default_factory=list)


class OnlinePlanner:
    """
    Plan -> execute -> verify -> replan. The agentic control loop, kept
    separate from the search so both can be tested.

    max_replans guards against model holes: after that many surprises on
    one goal the agent gives up and reports honestly (and the model has
    learned from every failed prediction — failure is tuition).
    """

    def __init__(
        self, model, max_replans: int = 4, max_explore: int = 16, rng=None
    ):
        self.model = model
        self.max_replans = max_replans
        self.max_explore = max_explore
        self.rng = rng or random.Random(0)

    def solve(
        self, world, goal: frozenset | None = None, h_fn=None
    ) -> SolveLog:
        goal = world.level.goal if goal is None else goal
        log = SolveLog()
        if world.achieved() or goal <= world.state:
            log.achieved = True
            return log
        explored = 0
        attempt = 0
        while attempt <= self.max_replans and explored <= self.max_explore:
            plan_ = plan(
                self.model, world.state, goal, world.applicable, h_fn=h_fn
            )
            log.plans += 1
            if plan_ is None:
                # BOOTSTRAP: the model is silent here, so imagination
                # cannot plan. Act to learn — the least-explored affordance
                # (novelty-driven exploration; "curiosity is competence
                #  about to happen"). Then try to plan again.
                acts = world.applicable()
                if not acts:
                    break
                # epsilon-exploration: mostly chase novelty (ties broken
                # by the seeded rng), sometimes just act — the wandering
                # that carries keys to doors before dropping them
                if self.rng.random() < 0.35:
                    a = self.rng.choice(acts)
                else:
                    top = max(self.model.novelty(world.state, x) for x in acts)
                    best = [
                        x
                        for x in acts
                        if self.model.novelty(world.state, x) == top
                    ]
                    a = self.rng.choice(best)
                prev = world.state
                true_next = world.step(a)
                self.model.observe(a, prev, true_next)
                log.steps += 1
                explored += 1
                log.events.append(("explore", a))
                if goal <= world.state:
                    log.achieved = True
                    return log
                continue
            prev = world.state
            broke = False
            for a in plan_.actions:
                true_next = world.step(a)
                predicted = self.model.predict(prev, a)
                self.model.observe(a, prev, true_next)
                log.steps += 1
                prev = true_next
                if predicted != true_next:
                    log.surprises += 1
                    log.events.append(("surprise", a))
                    broke = True
                    break  # imagination diverged -> replan from reality
            if not broke:
                if goal <= world.state:
                    log.achieved = True
                    log.events.append(("achieved", attempt))
                    return log
                log.events.append(("plan_exhausted", attempt))
                break
            attempt += 1  # a surprised plan consumes a replan budget
        log.achieved = goal <= world.state
        return log
