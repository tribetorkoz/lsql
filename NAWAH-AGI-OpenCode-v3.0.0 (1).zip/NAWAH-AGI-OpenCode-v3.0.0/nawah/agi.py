"""
AgiAgent — the full autonomous loop.

    perceive ──▶ propose goal ──▶ plan in the learned model ──▶ act
        ▲                                                         │
        │            surprise? ──▶ replan ◀───────────────────────┤
        │                                                         ▼
        └──────── memory / operators / skills ◀── verify ── consolidate

What it adds over the v3 NAWAH agent (and why — see AGI.md):
    * a WORLD MODEL learned from executed transitions (not just a router)
    * skills as OPERATORS with preconditions/effects (composable)
    * PLANNING toward goals that were never trained on
    * SELF-GENERATED goals (AZR learnability x CIG reachability)
    * META self-improvement of the policy genome (DGM-lite, empirical)

The iron rule survives unchanged: success is judged mechanically —
goal atoms in a state, exact-match outputs — never by taste.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field

from .goals import GoalProposer
from .memory import Memory
from .meta import MetaEvolver
from .planner import OnlinePlanner
from .worldmodel import WorldModel
from .worlds import SymbolicWorld, gen_level, gen_suite, map_heuristic


@dataclass
class Round:
    goal: frozenset
    success: bool
    steps: int
    plans: int
    surprises: int
    mode: str  # "directed" | "free"
    genome: str = ""


@dataclass
class AgiAgent:
    seed: int = 0
    max_replans: int = 3
    max_explore: int = 8
    search_nodes: int = 4000
    goal_rule: str = "learnability"
    free_play: int = 4
    verbose: bool = False

    # components (built in __post_init__ so a genome can configure them)
    model: WorldModel = field(default_factory=WorldModel)
    memory: Memory = field(default_factory=Memory)
    rounds: list = field(default_factory=list)

    def __post_init__(self):
        self.rng = random.Random(f"agi:{self.seed}")
        self.proposer = GoalProposer(
            memory=self.memory, model=self.model, rule=self.goal_rule
        )
        self.meta = MetaEvolver(seed=self.seed)

    # ── one goal, end to end ─────────────────────────────────
    def pursue(
        self,
        world: SymbolicWorld,
        goal: frozenset | None = None,
        mode: str = "directed",
    ) -> Round:
        goal = world.level.goal if goal is None else goal
        planner = OnlinePlanner(
            self.model,
            max_replans=self.max_replans,
            max_explore=self.max_explore,
        )
        log = planner.solve(world, goal, h_fn=map_heuristic(world.level))
        r = Round(
            goal=goal,
            success=log.achieved,
            steps=log.steps,
            plans=log.plans,
            surprises=log.surprises,
            mode=mode,
        )
        self.memory.record_episode(
            goal, (), log.achieved, log.surprises, log.steps
        )
        self.rounds.append(r)
        return r

    # ── free play: the agent chooses its own curriculum ──────
    def free_play_round(self, world: SymbolicWorld) -> Round | None:
        prop = self.proposer.propose(
            world.state, world.level, world.applicable
        )
        if prop is None or not prop.reachable:
            return None
        return self.pursue(world, prop.goal, mode="free")

    def live(self, level, n_goals: int = 6) -> list:
        """Directed goals first (the benchmark contract), then the agent's
        own goals — this is a mini developmental schedule:
        'do what is asked, then play to learn'."""
        out = []
        world = SymbolicWorld(level)
        out.append(self.pursue(world, mode="directed"))
        world = SymbolicWorld(level)  # fresh state for free play
        for _ in range(min(self.free_play, n_goals)):
            r = self.free_play_round(world)
            if r is not None:
                out.append(r)
            world = SymbolicWorld(world.level)
        return out

    # ── evaluation of a whole genome (for the meta loop) ─────
    def evaluate_genome(
        self, genes: dict, levels, fresh: bool = True
    ) -> float:
        """Score a policy genome on a level suite. Mechanical: fraction of
        directed goals achieved, minus a small surprise tax (plans that
        relied on a wrong model are worse even when they scrape through)."""
        if fresh:
            # a fresh judgement: empty model, empty memory, empty history.
            # Anything less and the 'after' number inherits what the
            # 'before' run happened to teach — an evaluation leak.
            self.model = WorldModel()
            self.memory = Memory()
            self.rounds = []
            self.__post_init__()
        self.max_replans = int(genes["max_replans"])
        self.max_explore = int(genes.get("max_explore", self.max_explore))
        self.goal_rule = genes["goal_rule"]
        self.free_play = int(genes["free_play"])
        self.proposer.rule = self.goal_rule
        score = 0.0
        total = 0
        for lv in levels:
            world = SymbolicWorld(lv)
            r = self.pursue(world, mode="directed")
            total += 1
            # mechanical score: did it work, and how cheaply?
            score += 1.0 if r.success else 0.0
            score += 0.15 / (1.0 + r.steps) if r.success else 0.0
            score -= 0.02 * r.surprises
            # free play is tuition — do not score it, only pay for it
            world2 = SymbolicWorld(lv)
            for _ in range(int(genes["free_play"])):
                self.free_play_round(world2)
                world2 = SymbolicWorld(lv)
        return score / max(1, total)

    # ── the meta loop, DGM-style ─────────────────────────────
    def evolve(self, train_levels, generations: int = 8) -> list:
        def evaluate(genome):
            # a PROBE agent judges each genome — this agent's own meta
            # archive must survive the judging (it once did not, and the
            # evolution became a very slow coin flip)
            probe = AgiAgent(seed=self.seed)
            return probe.evaluate_genome(
                genome.genes, train_levels, fresh=False
            )

        history = self.meta.run(evaluate, generations)
        best = self.meta.archive.best()
        if best:
            self.max_replans = int(best.genes["max_replans"])
            self.max_explore = int(
                best.genes.get("max_explore", self.max_explore)
            )
            self.goal_rule = best.genes["goal_rule"]
            self.free_play = int(best.genes["free_play"])
            self.proposer.rule = self.goal_rule
        return history

    def report(self) -> dict:
        wins = [r for r in self.rounds if r.success]
        return {
            "rounds": len(self.rounds),
            "success": len(wins),
            "directed_success": sum(
                1 for r in self.rounds if r.mode == "directed" and r.success
            ),
            "free_success": sum(
                1 for r in self.rounds if r.mode == "free" and r.success
            ),
            "avg_surprises": (
                sum(r.surprises for r in self.rounds)
                / max(1, len(self.rounds))
            ),
            "model": self.model.coverage(),
            "memory": self.memory.summary(),
            "genome": self.meta.archive.best().fingerprint()
            if self.meta.archive.best()
            else "",
        }


# ══════════════════════════════════════════════════════════════
# Benchmarks — mechanical, seeded, reproducible
# ══════════════════════════════════════════════════════════════
def bench_transfer(
    seed: int = 0, n_train: int = 8, n_test: int = 4, warm_per_level: int = 2
) -> dict:
    """Learn dynamics on TRAIN levels (renamed entities), then be
    tested on unseen TEST levels. The AGI-ish claim measured here:
    induced operators transfer; a lookup table cannot."""
    train, test = gen_suite(seed, n_train=n_train, n_test=n_test)
    # tight budgets on purpose: at a generous budget everything passes
    # and the benchmark measures nothing.
    ag = AgiAgent(seed=seed, max_replans=2, max_explore=6, free_play=0)
    for lv in train:
        for _k in range(warm_per_level):
            w = SymbolicWorld(lv)
            ag.pursue(w, mode="directed")
            w = SymbolicWorld(lv)
            ag.free_play_round(w)
    green = AgiAgent(seed=seed + 1, max_replans=2, max_explore=6, free_play=0)
    greenfield = []
    for lv in test:
        w = SymbolicWorld(lv)
        greenfield.append(green.pursue(w, mode="directed").success)
    cold, warm, cold_steps, warm_steps = [], [], [], []
    for lv in test:
        w = SymbolicWorld(lv)
        r = ag.pursue(w, mode="directed")
        cold.append(r.success)
        cold_steps.append(r.steps)
        w2 = SymbolicWorld(lv)
        ag.pursue(w2, mode="directed")  # one warm-up attempt on the level
        w3 = SymbolicWorld(lv)
        r = ag.pursue(w3, mode="directed")
        warm.append(r.success)
        warm_steps.append(r.steps)
    return {
        "n_train_levels": n_train,
        "n_test_levels": n_test,
        "greenfield": 100 * sum(greenfield) / len(greenfield),
        "cold_start": 100 * sum(cold) / len(cold),
        "after_one_attempt": 100 * sum(warm) / len(warm),
        "cold_avg_steps": sum(cold_steps) / len(cold_steps),
        "warm_avg_steps": sum(warm_steps) / len(warm_steps),
        "model": ag.model.coverage(),
    }


def bench_free_play(seed: int = 0, rounds: int = 30) -> dict:
    """Does self-generated practice build a usable model and competence?
    Measured by what the agent can do AFTERWARDS on directed goals
    it never chose."""
    train, test = gen_suite(seed, n_train=6, n_test=4)
    ag = AgiAgent(seed=seed, free_play=rounds)
    for lv in train:
        w = SymbolicWorld(lv)
        for _ in range(rounds // max(1, len(train))):
            ag.free_play_round(w)
            w = SymbolicWorld(lv)
    hits = []
    for lv in test:
        w = SymbolicWorld(lv)
        hits.append(ag.pursue(w, mode="directed").success)
    return {
        "free_rounds": rounds,
        "held_out_directed": 100 * sum(hits) / len(hits),
        "goals_mastered": ag.memory.mastered_goals(),
        "model": ag.model.coverage(),
    }


def bench_meta(seed: int = 0, generations: int = 10) -> dict:
    """DGM-lite: does evolving the policy genome beat the seed genome?
    Train and test suites are DISJOINT (the objective-hacking
    guard)."""
    # harder worlds for a harder question: deep goals, tight genomes.
    # At n_rooms<=9 every genome solves everything and the curve is flat;
    # at 10 the knobs separate the policies (weak 0, mixed 0, strong 34).
    train = [gen_level(seed + 77, tid=i, n_rooms=10) for i in range(6)]
    test = [gen_level(seed + 99, tid=i, n_rooms=10) for i in range(6)]
    neutral = {
        "max_replans": 3,
        "max_explore": 8,
        "search_nodes": 4000,
        "goal_rule": "learnability",
        "free_play": 4,
    }
    # the SAME judge seed for before/after — different judges would
    # shuffle tuition goals and confound the comparison
    before = AgiAgent(seed=seed + 5).evaluate_genome(neutral, test)

    ag = AgiAgent(seed=seed)
    history = ag.evolve(train, generations=generations)
    best = ag.meta.archive.best()
    after = AgiAgent(seed=seed + 5).evaluate_genome(best.genes, test)
    return {
        "generations": generations,
        "test_before": 100 * before,
        "test_after": 100 * after,
        "best_genes": best.genes,
        "lineage": ag.meta.archive.lineage(best),
        "curve": history,
    }


def bench_compare(seed: int = 0, n_levels: int = 6) -> dict:
    """Planning vs blind play on hard goals — the ablation the AGI claim
    needs: if the blind explorer matches the planner, the planner (and
    the world model behind it) is not earning anything."""
    levels = [gen_level(seed + 900, tid=i) for i in range(n_levels)]

    # (a) blind: novelty-driven actions only, no plan, same budget
    blind_hits, blind_steps = 0, 0
    for lv in levels:
        w = SymbolicWorld(lv)
        m = WorldModel()
        spent = 0
        while spent < 30 and not w.achieved():
            acts = w.applicable()
            a = max(acts, key=lambda a: m.novelty(w.state, a))
            prev = w.state
            nxt = w.step(a)
            m.observe(a, prev, nxt)
            spent += 1
        blind_hits += int(w.achieved())
        blind_steps += spent

    # (b) planner: full agent, tight budget
    ag = AgiAgent(seed=seed, max_replans=2, max_explore=6, free_play=0)
    plan_hits, plan_steps = 0, 0
    for lv in levels:
        w = SymbolicWorld(lv)
        r = ag.pursue(w, mode="directed")
        plan_hits += int(r.success)
        plan_steps += r.steps

    return {
        "levels": n_levels,
        "blind_success": 100 * blind_hits / n_levels,
        "planner_success": 100 * plan_hits / n_levels,
        "blind_avg_steps": blind_steps / n_levels,
        "planner_avg_steps": plan_steps / n_levels,
    }
