"""
Memory — episodes, competence estimates, and consolidation.

Three tiers, deliberately matching the Letta/MemGPT + A-MEM lessons of
2025-26 (dedicated memory helps only when it serves decisions):
    1. episodic: what happened, kept exactly (fast recall path)
    2. semantic: what WORKS — per-(state-feature, action) success counts,
       the competence estimates the goal-proposer needs
    3. reflective: per-goal outcomes, so the agent knows what it can and
       cannot do TODAY (AZR's learnability reward is built on exactly this)

Everything is plain data: exportable, diffable, testable.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass


@dataclass
class Episode:
    goal: frozenset
    actions: tuple
    success: bool
    surprises: int
    steps: int


class Memory:
    def __init__(self, cap: int = 2000):
        self.cap = cap
        self.episodes: list[Episode] = []
        # semantic: feature -> [successes, attempts]
        self.competence: dict = defaultdict(lambda: [0, 0])
        # reflective: goal fingerprint -> [successes, attempts]
        self.goal_record: dict = defaultdict(lambda: [0, 0])

    # ── recording ────────────────────────────────────────────
    def record_episode(self, goal, actions, success, surprises, steps):
        self.episodes.append(
            Episode(frozenset(goal), tuple(actions), success, surprises, steps)
        )
        if len(self.episodes) > self.cap:
            self.episodes = self.episodes[-self.cap :]
        fp = goal_fingerprint(goal)
        rec = self.goal_record[fp]
        rec[0] += int(success)
        rec[1] += 1

    def record_transition(self, feature: str, ok: bool):
        rec = self.competence[feature]
        rec[0] += int(ok)
        rec[1] += 1

    # ── queries (what the rest of the agent needs) ───────────
    def p_success(self, goal) -> float:
        """Posterior mean with a Beta(1,1) prior — untouched goals sit at
        .5, exactly like AZR's early-uncertainty behaviour."""
        s, n = self.goal_record[goal_fingerprint(goal)]
        return (s + 1.0) / (n + 2.0)

    def p_feature(self, feature: str) -> float:
        s, n = self.competence[feature]
        return (s + 1.0) / (n + 2.0)

    def mastered_goals(self) -> int:
        return sum(
            1 for s, n in self.goal_record.values() if n >= 2 and s == n
        )

    def summary(self) -> dict:
        return {
            "episodes": len(self.episodes),
            "goal_kinds": len(self.goal_record),
            "mastered": self.mastered_goals(),
            "success_rate": (
                sum(e.success for e in self.episodes) / len(self.episodes)
                if self.episodes
                else 0.0
            ),
        }


def goal_fingerprint(goal) -> str:
    """Stable id of a goal regardless of entity names where possible.

    Goals with the same predicate shape (e.g. has(agent, X)) share a
    fingerprint so competence transfers across renamed levels.
    """
    parts = []
    for a in sorted(goal):
        # entities that look like per-level names get generalised
        shape = tuple(
            "?"
            if (isinstance(x, str) and any(ch.isdigit() for ch in x))
            else x
            for x in a
        )
        parts.append(str(shape))
    return "|".join(parts)
