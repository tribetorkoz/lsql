"""End-to-end self-check:  python3 -m nawah.doctor

Answers one question with evidence: "is this installation actually
working?"  Every line below is executed, never assumed — the same rule
the project applies to its own claims.  Exit status 0 = healthy.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

OK, BAD, WARN = "✓", "✗", "!"


class Report:
    def __init__(self) -> None:
        self.rows: list[tuple[str, str, str]] = []

    def add(self, mark: str, name: str, detail: str = "") -> None:
        self.rows.append((mark, name, detail))

    def ok(self, name: str, detail: str = "") -> None:
        self.add(OK, name, detail)

    def bad(self, name: str, detail: str = "") -> None:
        self.add(BAD, name, detail)

    def warn(self, name: str, detail: str = "") -> None:
        self.add(WARN, name, detail)

    @property
    def failed(self) -> int:
        return sum(1 for m, _, _ in self.rows if m == BAD)

    def render(self) -> str:
        width = max((len(n) for _, n, _ in self.rows), default=10)
        lines = []
        for mark, name, detail in self.rows:
            lines.append(f"  {mark} {name.ljust(width)}  {detail}".rstrip())
        return "\n".join(lines)


def _repo_root() -> Path:
    """Where .opencode/ and opencode.json are expected to live.

    Order matters: an explicit NAWAH_PROJECT wins (the installer sets it),
    then the current directory, then the directory holding the package.
    Getting this wrong makes the doctor inspect the wrong project — which
    is exactly the kind of mistake a self-check must not make.
    """
    env = os.environ.get("NAWAH_PROJECT")
    if env:
        return Path(env).expanduser().resolve()
    cwd = Path.cwd()
    if (cwd / "opencode.json").exists() or (cwd / ".opencode").is_dir():
        return cwd
    here = Path(__file__).resolve().parent.parent
    return here if (here / "opencode.json").exists() else cwd


def check_python(rep: Report) -> None:
    v = sys.version_info
    if v >= (3, 10):
        rep.ok("python", f"{v.major}.{v.minor}.{v.micro} at {sys.executable}")
    else:
        rep.bad("python", f"{v.major}.{v.minor} — need >= 3.10")


def check_imports(rep: Report) -> None:
    mods = [
        "nawah",
        "nawah.worldmodel",
        "nawah.planner",
        "nawah.mcp_server",
        "nawah.codeworld",
        "nawah.oc_observe",
        "nawah.oc_skills",
        "nawah.oc_driver",
    ]
    missing = []
    for m in mods:
        try:
            __import__(m)
        except Exception as exc:
            missing.append(f"{m} ({type(exc).__name__})")
    if missing:
        rep.bad("core imports", ", ".join(missing))
    else:
        import nawah

        rep.ok("core imports", f"8 modules, nawah {nawah.__version__}")

    try:
        import numpy  # noqa: F401

        rep.ok("research harness", "numpy present — `nawah verify` available")
    except ModuleNotFoundError:
        rep.warn("research harness", "numpy absent — core features unaffected")


def check_storage(rep: Report) -> None:
    root = _repo_root()
    try:
        d = root / ".nawah"
        d.mkdir(exist_ok=True)
        probe = d / ".doctor"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        rep.ok("memory store", str(d))
    except OSError as exc:
        rep.bad("memory store", f"not writable: {exc}")


def check_mcp(rep: Report, timeout: float = 30.0) -> None:
    """Real JSON-RPC over stdio — the exact path OpenCode uses."""
    reqs = [
        {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}},
        {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}},
    ]
    payload = "\n".join(json.dumps(r) for r in reqs) + "\n"
    import nawah

    pkg_parent = str(Path(nawah.__file__).resolve().parent.parent)
    path = os.pathsep.join([p for p in (str(_repo_root()), pkg_parent) if p])
    env = dict(os.environ, PYTHONPATH=path)
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "nawah.mcp_server"],
            input=payload,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=env,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        rep.bad("mcp handshake", f"server did not run: {exc}")
        return
    tools, inited = [], False
    for line in proc.stdout.splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        if msg.get("id") == 1 and "result" in msg:
            inited = True
        if msg.get("id") == 2 and "result" in msg:
            tools = [t["name"] for t in msg["result"].get("tools", [])]
    if inited and tools:
        rep.ok(
            "mcp handshake", f"{len(tools)} tools: {', '.join(tools[:3])}..."
        )
    else:
        err = (proc.stderr or "").strip().splitlines()
        rep.bad(
            "mcp handshake",
            err[-1] if err else f"no tools in response (rc={proc.returncode})",
        )


def check_wiring(rep: Report) -> None:
    root = _repo_root()
    cfg = root / "opencode.json"
    if cfg.exists():
        try:
            data = json.loads(cfg.read_text(encoding="utf-8"))
            mcp = data.get("mcp", {}).get("nawah", {})
            cmd = mcp.get("command")
            if mcp and cmd:
                rep.ok("opencode.json", f"mcp.nawah -> {' '.join(cmd)}")
            else:
                rep.bad("opencode.json", "no mcp.nawah entry")
        except json.JSONDecodeError as exc:
            rep.bad("opencode.json", f"invalid JSON: {exc}")
    else:
        rep.bad("opencode.json", f"missing in {root}")

    files = {
        "plugin": ".opencode/plugins/nawah.ts",
        "agent": ".opencode/agents/nawah-planner.md",
        "command": ".opencode/commands/nawah.md",
    }
    for label, rel in files.items():
        p = root / rel
        if p.exists():
            rep.ok(f"wiring: {label}", rel)
        else:
            rep.warn(f"wiring: {label}", f"{rel} missing")

    skills = sorted((root / ".opencode" / "skills").glob("*/SKILL.md"))
    if skills:
        rep.ok("skills", f"{len(skills)} exported SKILL.md")
    else:
        rep.warn(
            "skills", "none — run: python3 -m nawah.oc_skills .opencode/skills"
        )


def check_brain(rep: Report) -> None:
    """Learn one transition, then predict it. Mechanics, not promises."""
    from nawah.worldmodel import WorldModel

    m = WorldModel()
    before = frozenset({"door", "closed", "at:room"})
    after = frozenset({"door", "open", "at:room"})
    m.observe("open", before, after)
    pred = m.predict(before, "open")
    if pred == after:
        rep.ok("world model", "observe -> predict round-trip exact")
    else:
        rep.bad("world model", f"prediction mismatch: {sorted(pred or [])}")


def check_code_reader(rep: Report) -> None:
    from nawah.codeworld import facts_from_tree, scan_summary

    root = Path(__file__).resolve().parent
    facts = facts_from_tree(root)
    s = scan_summary(facts)
    if s["functions"] > 100 and not s["invalid"]:
        rep.ok(
            "code reader",
            f"{s['modules']} modules, {s['functions']} functions, "
            f"{s['call_edges']} call edges",
        )
    else:
        rep.bad("code reader", f"unexpected scan: {s}")


def check_tests(rep: Report) -> None:
    root = _repo_root()
    if not (root / "tests").is_dir():
        rep.warn("test suite", "no tests/ directory (installed package?)")
        return
    if not shutil.which(sys.executable):
        rep.warn("test suite", "python executable not on PATH")
        return
    try:
        r = subprocess.run(
            [sys.executable, "-m", "pytest", "-q", "tests"],
            cwd=root,
            capture_output=True,
            text=True,
            timeout=900,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        rep.warn("test suite", f"not run: {exc}")
        return
    tail = [ln for ln in r.stdout.strip().splitlines() if ln.strip()]
    summary = tail[-1] if tail else "no output"
    if r.returncode == 0:
        rep.ok("test suite", summary[:70])
    else:
        rep.bad("test suite", summary[:70])


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    with_tests = "--tests" in argv
    as_json = "--json" in argv

    rep = Report()
    check_python(rep)
    check_imports(rep)
    check_storage(rep)
    check_mcp(rep)
    check_wiring(rep)
    check_brain(rep)
    check_code_reader(rep)
    if with_tests:
        check_tests(rep)

    if as_json:
        print(
            json.dumps(
                {
                    "ok": rep.failed == 0,
                    "failed": rep.failed,
                    "checks": [
                        {"status": m, "name": n, "detail": d}
                        for m, n, d in rep.rows
                    ],
                },
                ensure_ascii=False,
                indent=2,
            )
        )
    else:
        print("NAWAH-AGI doctor — installation self-check")
        print(rep.render())
        verdict = (
            "HEALTHY" if rep.failed == 0 else f"{rep.failed} CHECK(S) FAILED"
        )
        print(f"\n  verdict: {verdict}")
    return 0 if rep.failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
