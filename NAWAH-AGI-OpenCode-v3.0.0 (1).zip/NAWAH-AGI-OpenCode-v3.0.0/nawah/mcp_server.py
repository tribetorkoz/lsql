"""
NAWAH-AGI as an MCP server — the programmatic bridge to OpenCode (and
any other MCP client). Pure stdlib: JSON-RPC 2.0 over stdio, no pip.

OpenCode wiring (opencode.json):

    { "mcp": { "nawah": { "type": "local",
        "command": ["python3", "-m", "nawah.mcp_server"] } } }

Facts cross the wire as strings:  "predicate" or "predicate:arg:arg..."
which map to atoms ("predicate",) / ("predicate", "arg", "arg").  This
keeps the engine domain-free: rooms and keys today, tests passing and
files merged tomorrow.

Protocol note: stdout belongs to JSON-RPC. Every log goes to stderr.
"""

from __future__ import annotations

import json
import random
import sys
from dataclasses import dataclass, field

from .goals import GoalProposer
from .memory import Memory
from .meta import MetaEvolver
from .planner import PlanCache, plan_hierarchical
from .worldmodel import WorldModel

PROTOCOL_VERSION = "2025-06-18"
SERVER_INFO = {"name": "nawah-agi", "version": "2.0"}


# ── fact strings ↔ atoms ────────────────────────────────────────────
def fact_to_atom(f: str) -> tuple:
    parts = f.split(":")
    return tuple(parts) if len(parts) > 1 else (parts[0],)


def atom_to_fact(a: tuple) -> str:
    return ":".join(a)


def facts_to_state(facts) -> frozenset:
    # accept both wire-format fact strings and raw atom tuples (the
    # planner passes states internally; the MCP wire passes strings)
    out = set()
    for f in facts:
        out.add(f if isinstance(f, tuple) else fact_to_atom(f))
    return frozenset(out)


def state_to_facts(state) -> list:
    return sorted(atom_to_fact(a) for a in state)


# ── the live brain ──────────────────────────────────────────────────
@dataclass
class Brain:
    """One learned world + the planners above it."""

    model: WorldModel = field(default_factory=WorldModel)
    memory: Memory = field(default_factory=Memory)
    cache: PlanCache = field(default_factory=PlanCache)
    state: frozenset = frozenset()
    actions_seen: set = field(default_factory=set)
    episodes: list = field(default_factory=list)
    rng: random.Random = field(default_factory=lambda: random.Random(0))

    def observe(self, action: str, before, after) -> dict:
        s = facts_to_state(before)
        s2 = facts_to_state(after)
        surprise = self.model.observe(action, s, s2)
        self.actions_seen.add(action)
        self.state = s2
        name, _, argstr = action.partition(":")
        nargs = len(argstr.split(",")) if argstr else 0
        key = name + "(" + ",".join(f"?A{i}" for i in range(nargs)) + ")"
        op = self.model.ops.get(key)
        learned = None
        if op is not None:
            learned = {
                "schema": key,
                "n_obs": op.n_obs,
                "preconditions": [atom_to_fact(a) for a in op.pre],
                "effects_add": [atom_to_fact(a) for a in op.add],
                "effects_del": [atom_to_fact(a) for a in op.dele],
            }
        return {"surprise": bool(surprise), "learned": learned}

    def predict(self, before, action) -> dict:
        s = facts_to_state(before)
        s2 = self.model.predict(s, action)
        return {
            "predicted": None if s2 is None else state_to_facts(s2),
            "knows_action": action in self.model.ops,
        }

    def applicable(self, before=None) -> list:
        s = self.state if before is None else facts_to_state(before)
        out = []
        for a in sorted(self.actions_seen):
            s2 = self.model.predict(s, a)
            if s2 is not None:
                out.append(a)
        return out

    def plan(self, goal_facts, use_cache: bool = True) -> dict:
        goal = facts_to_state(goal_facts)
        if goal <= self.state:
            return {
                "plan": [],
                "from_cache": False,
                "steps": 0,
                "solved_at_start": True,
            }
        pl = plan_hierarchical(
            self.model,
            self.state,
            goal,
            self.applicable,
            cache=self.cache if use_cache else None,
        )
        if pl is None:
            return {
                "plan": None,
                "reason": "no plan under the learned model — explore more "
                "(nawah_observe) or widen search_nodes",
            }
        self.episodes.append((goal, list(pl.actions)))
        return {
            "plan": list(pl.actions),
            "steps": len(pl.actions),
            "from_cache": pl.from_cache,
            "explored": pl.explored,
            "predicted_end": state_to_facts(pl.predicted[-1]),
        }

    def replan(self, goal_facts, failed_action=None) -> dict:
        goal = facts_to_state(goal_facts)
        dropped = self.cache.invalidate_goal(goal)
        info = {"cache_entries_dropped": dropped}
        if failed_action is not None:
            info["note"] = (
                f"action {failed_action!r} surprised the model; its "
                "schema has been refined by the latest observation"
            )
        return {**info, **self.plan(goal_facts, use_cache=True)}

    def propose_goal(self) -> dict:
        prop = GoalProposer(
            memory=self.memory, model=self.model, rule="learnability"
        )

        class _Level:
            goal = frozenset()

        p = prop.propose(self.state, _Level(), self.applicable)
        if p is None:
            return {"goal": None}
        return {
            "goal": [atom_to_fact(a) for a in p.goal],
            "learnability": round(p.learnability, 3),
            "reachable": p.reachable,
        }

    def code_scan(self, path: str) -> dict:
        from .codeworld import facts_from_tree, scan_summary

        facts = facts_from_tree(path)
        self.actions_seen.add("code:scan")
        return {
            "summary": scan_summary(facts),
            "facts": sorted(":".join(map(str, a)) for a in facts)[:400],
        }

    def code_impact(self, action: str, before: list) -> dict:
        from .codeworld import CodeWorld

        cw = CodeWorld(model=self.model)
        return cw.impact(action, facts_to_state(before))

    def status(self) -> dict:
        return {
            "model": self.model.coverage(),
            "state": state_to_facts(self.state),
            "actions_known": sorted(self.actions_seen),
            "plan_cache": {
                "size": len(self.cache),
                "hits": self.cache.hits,
                "misses": self.cache.misses,
            },
            "episodes": len(self.episodes),
            "memory": self.memory.summary(),
        }

    def evolve(self, generations: int = 6) -> dict:
        if not self.episodes:
            return {"error": "no episodes yet — plan something first"}
        suite = [g for g, _a in self.episodes[-12:]]
        ev = MetaEvolver(seed=0)

        def evaluate(genome):
            score = 0.0
            for g in suite:
                pl = plan_hierarchical(
                    self.model,
                    self.state,
                    g,
                    self.applicable,
                    max_nodes=int(genome.genes.get("search_nodes", 4000)),
                )
                if pl is not None:
                    score += 1.0 + 0.15 / (1 + len(pl.actions))
            return score / max(1, len(suite))

        history = ev.run(evaluate, generations)
        best = ev.archive.best()
        return {
            "best_genes": best.genes,
            "lineage": ev.archive.lineage(best),
            "curve": [(g, round(s, 3)) for g, s, _b in history],
        }


# ── MCP tool schemas ───────────────────────────────────────────────
_FACTS = {"type": "array", "items": {"type": "string"}}
TOOLS = [
    {
        "name": "nawah_status",
        "description": "NAWAH-AGI brain status: learned model coverage, "
        "current state, plan-cache statistics, memory.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "nawah_observe",
        "description": "Teach NAWAH a transition: what the world looked "
        "like before an action and after it. Every call "
        "refines the lifted operator model. Use it after "
        "meaningful actions (test runs, edits, builds).",
        "inputSchema": {
            "type": "object",
            "required": ["action", "before", "after"],
            "properties": {
                "action": {"type": "string"},
                "before": _FACTS,
                "after": _FACTS,
            },
        },
    },
    {
        "name": "nawah_predict",
        "description": "Predict the outcome of an action in a state under "
        "the learned model. Null means the model honestly "
        "does not know.",
        "inputSchema": {
            "type": "object",
            "required": ["action", "before"],
            "properties": {"action": {"type": "string"}, "before": _FACTS},
        },
    },
    {
        "name": "nawah_applicable",
        "description": "List actions the learned model believes apply in "
        "the current (or a given) state.",
        "inputSchema": {"type": "object", "properties": {"before": _FACTS}},
    },
    {
        "name": "nawah_state_set",
        "description": "Set the current world state as a list of facts "
        "(e.g. ['tests:passing', 'lint:clean']).",
        "inputSchema": {
            "type": "object",
            "required": ["facts"],
            "properties": {"facts": _FACTS},
        },
    },
    {
        "name": "nawah_plan",
        "description": "Plan in imagination toward a goal state given as "
        "facts. Uses the learned world model, hierarchical "
        "landmark decomposition and case-based plan reuse. "
        "Returns an ordered action sequence. Call this "
        "BEFORE writing code for multi-step tasks.",
        "inputSchema": {
            "type": "object",
            "required": ["goal"],
            "properties": {"goal": _FACTS, "use_cache": {"type": "boolean"}},
        },
    },
    {
        "name": "nawah_replan",
        "description": "Reality diverged from the plan (a test failed, an "
        "edit conflicted). Invalidate cached plans for this "
        "goal and replan from the current state.",
        "inputSchema": {
            "type": "object",
            "required": ["goal"],
            "properties": {
                "goal": _FACTS,
                "failed_action": {"type": "string"},
            },
        },
    },
    {
        "name": "nawah_goal_propose",
        "description": "Propose a learnable, reachable subgoal given what "
        "the model knows — useful to break a stalled task.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "nawah_code_scan",
        "description": "Read a directory of Python code into symbolic "
        "facts (defines, classes, imports, call edges, "
        "syntax validity). This is NAWAH's own structural "
        "understanding of code — use before planning "
        "edits so goals can reference real symbols.",
        "inputSchema": {
            "type": "object",
            "required": ["path"],
            "properties": {"path": {"type": "string"}},
        },
    },
    {
        "name": "nawah_code_impact",
        "description": "Predict the fact-level impact of a code-edit "
        "action under the learned model: which facts it "
        "will add/remove. Null/known:false means the model "
        "has no theory yet — observe the edit first.",
        "inputSchema": {
            "type": "object",
            "required": ["action", "before"],
            "properties": {"action": {"type": "string"}, "before": _FACTS},
        },
    },
    {
        "name": "nawah_evolve",
        "description": "DGM-lite: evolve planning genes on the tasks seen "
        "this session (train/evaluated on held-out slices). "
        "Returns best genes with lineage. This is the "
        "self-improvement step — use it sparingly.",
        "inputSchema": {
            "type": "object",
            "properties": {"generations": {"type": "integer"}},
        },
    },
]


# ── JSON-RPC plumbing ──────────────────────────────────────────────
def _ok(req_id, result):
    return {"jsonrpc": "2.0", "id": req_id, "result": result}


def _err(req_id, code, message):
    return {
        "jsonrpc": "2.0",
        "id": req_id,
        "error": {"code": code, "message": message},
    }


def handle(msg: dict, brain: Brain) -> dict | None:
    method = msg.get("method", "")
    mid = msg.get("id")
    params = msg.get("params") or {}
    if method == "initialize":
        return _ok(
            mid,
            {
                "protocolVersion": params.get(
                    "protocolVersion", PROTOCOL_VERSION
                ),
                "capabilities": {"tools": {}},
                "serverInfo": SERVER_INFO,
            },
        )
    if method == "notifications/initialized":
        return None
    if method == "ping":
        return _ok(mid, {})
    if method == "tools/list":
        return _ok(mid, {"tools": TOOLS})
    if method == "tools/call":
        name = params.get("name", "")
        args = params.get("arguments") or {}
        try:
            result = call_tool(name, args, brain)
            return _ok(
                mid,
                {
                    "content": [
                        {
                            "type": "text",
                            "text": json.dumps(result, ensure_ascii=False),
                        }
                    ],
                    "isError": False,
                },
            )
        except Exception as exc:  # tool errors are results, not crashes
            return _ok(
                mid,
                {
                    "content": [
                        {
                            "type": "text",
                            "text": f"{type(exc).__name__}: {exc}",
                        }
                    ],
                    "isError": True,
                },
            )
    if mid is not None:
        return _err(mid, -32601, f"method not found: {method}")
    return None


def call_tool(name: str, args: dict, brain: Brain) -> dict:
    if name == "nawah_status":
        return brain.status()
    if name == "nawah_observe":
        return brain.observe(args["action"], args["before"], args["after"])
    if name == "nawah_predict":
        return brain.predict(args["before"], args["action"])
    if name == "nawah_applicable":
        return {"applicable": brain.applicable(args.get("before"))}
    if name == "nawah_state_set":
        brain.state = facts_to_state(args["facts"])
        return {"state": state_to_facts(brain.state)}
    if name == "nawah_plan":
        return brain.plan(args["goal"], use_cache=args.get("use_cache", True))
    if name == "nawah_replan":
        return brain.replan(args["goal"], args.get("failed_action"))
    if name == "nawah_goal_propose":
        return brain.propose_goal()
    if name == "nawah_code_scan":
        return brain.code_scan(args["path"])
    if name == "nawah_code_impact":
        return brain.code_impact(args["action"], args["before"])
    if name == "nawah_evolve":
        return brain.evolve(int(args.get("generations", 6)))
    raise ValueError(f"unknown tool: {name}")


def serve(inp=None, out=None) -> None:
    inp = inp or sys.stdin
    out = out or sys.stdout
    brain = Brain()
    for line in inp:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        resp = handle(msg, brain)
        if resp is not None:
            out.write(json.dumps(resp, ensure_ascii=False) + "\n")
            out.flush()


def main() -> int:
    serve()
    return 0


if __name__ == "__main__":
    sys.exit(main())
