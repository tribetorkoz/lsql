"""
Worlds — deterministic, mechanically-verifiable environments with goals.

Why a symbolic world and not strings?
    The old suite proved the loop can memorise and re-apply text ops.
    A "mini-AGI" needs what ARC-AGI-3 calls agentic intelligence:
    explore a world, infer what is true, build a model of how actions
    change it, and plan multi-step sequences toward a goal that was
    never trained on. This environment provides exactly that, while
    keeping NAWAH's iron rule: verification is mechanical, no judgement.

Design (a research-grounded synthesis):
    * rooms/keys/doors/treasure  -> preconditions & effects exist, so
      skills can become OPERATORS and planning is possible (HTN/STRIPS
      tradition; ChatHTN, GoalAct, HCL-GP 2025-26).
    * levels are procedurally generated with renamed entities -> success
      on a new level requires TRUE generalisation (anti-unification),
      not lookup (Chollet's skill-acquisition criterion; ARC framing).
    * the agent is never told the dynamics: it must learn an operator
      model from executed transitions (world-model line: HWM 2026,
      Curiosity-Driven Imagination 2025).

Everything here is deterministic given a seed.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field


# ── predicates are plain tuples: ("at", "agent", "r0") ──────────
def atom(pred: str, *args) -> tuple:
    return (pred, *args)


def fmt_state(state) -> str:
    return ", ".join(
        f"{a[0]}({','.join(map(str, a[1:]))})" for a in sorted(state)
    )


@dataclass
class Level:
    """One generated world instance."""

    rooms: list
    # undirected edges: (room_a, room_b, door_id)
    edges: list
    # door_id -> key_id (locked doors need a key); None = unlocked
    locks: dict
    # item_id -> room
    items: dict
    # goal: set of atoms that must hold
    goal: frozenset
    # static facts (the map): connectivity + item placement + locks
    static: frozenset = field(default_factory=frozenset)
    start: str = ""
    tid: int = 0

    def start_state(self) -> frozenset:
        s = set(self.static)
        s.add(atom("at", "agent", self.start))
        for item, room in self.items.items():
            s.add(atom("item_at", item, room))
        return frozenset(s)


class SymbolicWorld:
    """
    A rooms-keys-doors world. The ENVIRONMENT owns the true dynamics;
    the agent must induce them from (state, action, state') samples.

    Actions (grounded strings, discoverable from a state):
        go:R2        move to adjacent room R2 through an open passage
        unlock:D1    open locked door D1 (needs its key in hand)
        take:K1      pick up item K1 in the current room
        drop:K1      drop item K1 in the current room
    """

    def __init__(self, level: Level):
        self.level = level
        self.state = level.start_state()
        self.t = 0

    # ── ground-truth dynamics (the agent does NOT see this code) ──
    def _room_of_agent(self, s=None) -> str:
        s = s or self.state
        for a in s:
            if a[0] == "at" and a[1] == "agent":
                return a[2]
        return ""

    def _held(self, s=None):
        s = s or self.state
        return {a[2] for a in s if a[0] == "has" and a[1] == "agent"}

    def _neighbors(self, room):
        out = []
        for a, b, door in self.level.edges:
            if a == room:
                out.append((b, door))
            elif b == room:
                out.append((a, door))
        return out

    def _door_open(self, door: str, s) -> bool:
        lock = self.level.locks.get(door)
        return lock is None or atom("unlocked", door) in s

    def applicable(self, s=None) -> list:
        """Grounded action strings legal in state s (the affordances)."""
        s = s or self.state
        room = self._room_of_agent(s)
        held = self._held(s)
        out = []
        for nb, door in self._neighbors(room):
            if self._door_open(door, s):
                out.append(f"go:{nb}")
            else:
                key = self.level.locks[door]
                if key in held:
                    out.append(f"unlock:{door}")
        for item, iroom in self.level.items.items():
            if iroom == room and atom("item_at", item, room) in s:
                out.append(f"take:{item}")
        for item in held:
            out.append(f"drop:{item}")
        return sorted(set(out))

    def step(self, action: str, s=None) -> frozenset:
        """Apply action to state s (or the live state). Returns the new state.

        Raises ValueError on an illegal action — planning must respect
        preconditions; the environment will not silently no-op.
        """
        live = s is None
        s = self.state if live else s
        if action not in self.applicable(s):
            raise ValueError(f"illegal action {action!r} in {fmt_state(s)}")
        s2 = set(s)
        name, _, arg = action.partition(":")
        if name == "go":
            s2.discard(atom("at", "agent", self._room_of_agent(s)))
            s2.add(atom("at", "agent", arg))
        elif name == "unlock":
            s2.add(atom("unlocked", arg))
        elif name == "take":
            s2.discard(atom("item_at", arg, self._room_of_agent(s)))
            s2.add(atom("has", "agent", arg))
        elif name == "drop":
            s2.discard(atom("has", "agent", arg))
            s2.add(atom("item_at", arg, self._room_of_agent(s)))
        self.t += 1
        if live:
            self.state = frozenset(s2)
        return frozenset(s2)

    def achieved(self, s=None) -> bool:
        s = s or self.state
        return self.level.goal <= s

    def goal_unmet(self, s=None) -> frozenset:
        s = s or self.state
        return self.level.goal - s


# ══════════════════════════════════════════════════════════════
# Level generation — procedural, seeded, renamed entities
# ══════════════════════════════════════════════════════════════
def gen_level(
    seed: int,
    n_rooms: int = 8,
    n_locked: int = 3,
    n_items: int = 2,
    tid: int = 0,
) -> Level:
    """
    A connected room graph (a ring plus a chord), some doors locked behind
    keys placed in other rooms, plus treasure-like items. Goals reference
    items and/or far rooms, so most goals need 3-8 grounded steps and
    sometimes a key detour — a real planning problem, not a lookup.
    """
    rng = random.Random(f"level:{seed}:{n_rooms}:{n_locked}:{n_items}:{tid}")
    rooms = [f"r{seed}_{i}" for i in range(n_rooms)]

    # ring for connectivity
    edges = []
    for i in range(n_rooms):
        a, b = rooms[i], rooms[(i + 1) % n_rooms]
        edges.append((a, b, f"d{seed}_{i}"))
    # one chord for redundancy (so a locked ring door is not a dead end)
    if n_rooms > 3:
        i = rng.randrange(n_rooms)
        a, b = rooms[i], rooms[(i + 2) % n_rooms]
        if not any({a, b} == {x, y} for x, y, _ in edges):
            edges.append((a, b, f"d{seed}_chord"))

    doors = [d for _a, _b, d in edges]
    rng.shuffle(doors)
    locked = doors[:n_locked]
    locks = {d: f"key{seed}_{d}" for d in locked}

    # SOLVABILITY GUARANTEE: every key must sit in the region reachable
    items = {}
    # from the start WITHOUT opening any lock. Otherwise a level can be
    # unsolvable — a key behind its own door — and every honest agent
    # fails forever, which measures the generator, not the agent.
    reach = {rooms[0]}
    grew = True
    while grew:
        grew = False
        for a, b, d in edges:
            if d in locks:
                continue
            for x, y in ((a, b), (b, a)):
                if x in reach and y not in reach:
                    reach.add(y)
                    grew = True
    region = [r for r in rooms if r in reach] or rooms[:]
    free_rooms = region[:]
    rng.shuffle(free_rooms)
    for door in locked:
        key = locks[door]
        ends = {a for a, b, d in edges if d == door} | {
            b for a, b, d in edges if d == door
        }
        candidates = [r for r in free_rooms if r not in ends] or free_rooms
        items[key] = candidates[0]
    for i in range(n_items):
        items[f"gem{seed}_{i}"] = rooms[(i + 1) % len(rooms)]

    static = set()
    for a, b, d in edges:
        static.add(atom("adj", a, b, d))
        static.add(atom("adj", b, a, d))
    for d, k in locks.items():
        static.add(atom("needs", d, k))
    for item, room in items.items():
        static.add(atom("at_room_of", item, room))  # into item_at at start

    # goal: hold one gem, or sit in the farthest room, or both
    farthest = rooms[n_rooms // 2]
    gems = [it for it in items if it.startswith("gem")]
    if gems and rng.random() < 0.7:
        goal = {atom("has", "agent", rng.choice(gems))}
    else:
        goal = {atom("at", "agent", farthest)}
    if rng.random() < 0.5 and gems:
        goal.add(atom("at", "agent", farthest))

    return Level(
        rooms=rooms,
        edges=edges,
        locks=locks,
        items=items,
        goal=frozenset(g for g in goal if g),
        static=frozenset(static),
        start=rooms[0],
        tid=tid,
    )


def gen_suite(seed: int, n_train: int = 8, n_test: int = 4):
    """Train/test LEVELS with disjoint room names — transfer must be real."""
    train = [gen_level(seed, tid=i) for i in range(n_train)]
    test = [gen_level(seed + 5000, tid=i) for i in range(n_test)]
    return train, test


def map_heuristic(level: Level):
    """
    A relaxed-plan heuristic over the known floor plan.

    The agent knows its own map (a robot has floor plans) but NOT which
    key opens which door until it learns it — so distances ignore locks.
    Goal atoms are priced by what they would take IF nothing were locked:
        at(agent, R)   -> walk distance
        has(agent, I)  -> walk to I's room, then pick it up
        unlocked(D)    -> walk to a key for D, pick it up, walk to D
    This is exactly the classic relaxed-heuristic trick (h_add-style),
    and it is what turns goal-count plateaus into a guide.
    """
    from collections import deque

    adj = {}
    for a, b, _d in level.edges:
        adj.setdefault(a, set()).add(b)
        adj.setdefault(b, set()).add(a)

    def dist(src, dst):
        if src == dst:
            return 0
        seen = {src}
        q = deque([(src, 0)])
        while q:
            cur, dd = q.popleft()
            for nb in adj.get(cur, ()):
                if nb == dst:
                    return dd + 1
                if nb not in seen:
                    seen.add(nb)
                    q.append((nb, dd + 1))
        return 9  # unreachable in the relaxation: still far

    def h(state, goal):
        here = next(
            (a[2] for a in state if a[0] == "at" and a[1] == "agent"), None
        )
        held = {a[2] for a in state if a[0] == "has" and a[1] == "agent"}
        total = 0
        for g in goal:
            if g in state:
                continue
            if g[0] == "at":
                total += dist(here, g[2])
            elif g[0] == "has":
                if g[2] in held:
                    continue
                room = level.items.get(g[2])
                total += dist(here, room) + 1 if room is not None else 3
            elif g[0] == "unlocked":
                key = level.locks.get(g[1])
                if key is not None and key not in held:
                    kroom = level.items.get(key)
                    total += dist(here, kroom) + 2 if kroom is not None else 3
                else:
                    total += 1
        return total

    return h
