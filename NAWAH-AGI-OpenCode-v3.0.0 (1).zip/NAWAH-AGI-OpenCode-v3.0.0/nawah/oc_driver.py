"""
NAWAH-AGI as the brain that DRIVES an OpenCode server.

Where the MCP route teaches OpenCode to call NAWAH, this route inverts
the arrow: NAWAH owns the task, OpenCode executes plan steps. The loop
is the whole product:

    facts -> nawah_plan -> prompt OpenCode (one step) -> probe facts
          -> nawah_observe -> surprise? -> nawah_replan -> ... -> verified

Transport: the OpenCode HTTP API (OpenAPI 3.1 at /doc; default server
127.0.0.1:4096 from `opencode serve`). Stdlib only — no npm required.

    python3 -m nawah.oc_driver --task "add health endpoint" \
        --goal "tests:passing,api:health:exists" \
        --probe "python3 probe_facts.py"
"""

from __future__ import annotations

import json
import subprocess
import urllib.error
import urllib.request
from dataclasses import dataclass, field

from .mcp_server import Brain, facts_to_state
from .planner import plan_hierarchical


class OpenCodeClient:
    """Thin stdlib client for the OpenCode server API."""

    def __init__(
        self, base_url: str = "http://127.0.0.1:4096", timeout: float = 600.0
    ):
        self.base = base_url.rstrip("/")
        self.timeout = timeout

    def _req(self, method: str, path: str, body: dict | None = None):
        data = None if body is None else json.dumps(body).encode()
        req = urllib.request.Request(
            self.base + path,
            data=data,
            method=method,
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                raw = r.read().decode() or "{}"
                return json.loads(raw)
        except urllib.error.HTTPError as e:
            raw = e.read().decode() or "{}"
            try:
                return json.loads(raw)
            except json.JSONDecodeError:
                return {"error": f"HTTP {e.code}", "body": raw}

    # ── sessions ────────────────────────────────────────────
    def create_session(self, title: str = "nawah") -> str:
        r = self._req("POST", "/session", {"title": title})
        return (r.get("data") or r).get("id") or r.get("id")

    def prompt(self, session_id: str, text: str, agent: str = "build") -> dict:
        body = {"parts": [{"type": "text", "text": text}], "agent": agent}
        r = self._req("POST", f"/session/{session_id}/message", body)
        if isinstance(r, dict) and ("error" in r and "id" not in r):
            r = self._req("POST", f"/session/{session_id}/prompt", body)
        return r

    def messages(self, session_id: str) -> list:
        r = self._req("GET", f"/session/{session_id}/message")
        return (r.get("data") or r) if isinstance(r, (list, dict)) else []


@dataclass
class Orchestrator:
    """The plan -> execute -> verify loop over an OpenCode session."""

    client: OpenCodeClient
    session_id: str
    brain: Brain = field(default_factory=Brain)
    probe: object = None  # callable() -> list[str] of current facts
    max_surprises: int = 4
    agent: str = "build"

    def current_facts(self) -> list[str]:
        if self.probe is not None:
            return list(self.probe())
        return sorted(":".join(a) for a in self.brain.state)

    def run(self, goal_facts: list[str], task_brief: str) -> dict:
        goal = facts_to_state(goal_facts)
        surprises = 0
        steps_done: list[str] = []
        # initial world
        facts = self.current_facts()
        self.brain.state = facts_to_state(facts)
        for _round in range(12):
            pl = plan_hierarchical(
                self.brain.model,
                self.brain.state,
                goal,
                self.brain.applicable,
                cache=self.brain.cache,
            )
            if pl is None and not self.brain.actions_seen:
                # cold start: let OpenCode take one exploratory step
                self.client.prompt(
                    self.session_id,
                    f"Task: {task_brief}\nGoal facts: {goal_facts}\n"
                    "Take ONE small step toward the goal. After it, "
                    "report what changed as before/after facts.",
                    agent=self.agent,
                )
                after = self.current_facts()
                self.brain.observe("explore:step", facts, after)
                facts = after
                continue
            if pl is None:
                return {
                    "success": False,
                    "reason": "model exhausted",
                    "steps": steps_done,
                    "surprises": surprises,
                }
            if goal <= self.brain.state:
                return {
                    "success": True,
                    "steps": steps_done,
                    "surprises": surprises,
                    "verified": True,
                }
            for a in pl.actions:
                before = self.current_facts()
                self.client.prompt(
                    self.session_id,
                    f"Execute exactly this step: {a}\n"
                    f"Task context: {task_brief}",
                    agent=self.agent,
                )
                after = self.current_facts()
                surprise = self.brain.observe(a, before, after)
                steps_done.append(a)
                if surprise["surprise"]:
                    surprises += 1
                    if surprises >= self.max_surprises:
                        return {
                            "success": goal <= self.brain.state,
                            "steps": steps_done,
                            "surprises": surprises,
                            "reason": "surprise budget spent",
                        }
                    self.brain.cache.invalidate_goal(goal)
                    break  # replan from here
            else:
                continue
        return {
            "success": goal <= self.brain.state,
            "steps": steps_done,
            "surprises": surprises,
        }


def shell_probe(command: str):
    """A fact probe that runs a command; stdout lines ARE the facts."""

    def probe() -> list[str]:
        out = subprocess.run(
            command, shell=True, capture_output=True, text=True, timeout=120
        )
        return [ln.strip() for ln in out.stdout.splitlines() if ln.strip()]

    return probe


def main() -> int:
    import argparse

    ap = argparse.ArgumentParser(description="Drive OpenCode from NAWAH")
    ap.add_argument("--task", required=True)
    ap.add_argument("--goal", required=True, help="comma-separated goal facts")
    ap.add_argument(
        "--probe", default="", help="shell command printing current facts"
    )
    ap.add_argument("--url", default="http://127.0.0.1:4096")
    ap.add_argument("--agent", default="build")
    args = ap.parse_args()
    client = OpenCodeClient(args.url)
    sid = client.create_session("nawah-task")
    if not sid:
        print(
            json.dumps(
                {
                    "error": "could not create session — "
                    "is `opencode serve` running?"
                }
            )
        )
        return 1
    orch = Orchestrator(
        client,
        sid,
        probe=shell_probe(args.probe) if args.probe else None,
        agent=args.agent,
    )
    goal = [g.strip() for g in args.goal.split(",") if g.strip()]
    result = orch.run(goal, args.task)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("success") else 2


if __name__ == "__main__":
    raise SystemExit(main())
