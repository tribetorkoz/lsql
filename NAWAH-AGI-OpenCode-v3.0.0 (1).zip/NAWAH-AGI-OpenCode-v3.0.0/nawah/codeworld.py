"""
Code as a world — NAWAH-AGI reads REAL code into symbolic facts.

This module is the answer to "can it understand code itself?".  The
mechanical definition of understanding (Chollet, and every verification
toolchain since): a system understands code to the extent that it can

    1. describe its STRUCTURE   (definitions, imports, calls, tests),
    2. PREDICT the fact-delta of an edit before making it,
    3. VERIFY the result against oracles (tests, lint, types).

L1 is stdlib ``ast`` — genuine parsing, not regex. L2 is the learned
world model over code facts: edit operators with lifted preconditions
and effects, transferred across renamed modules (the same lifting that
carried rooms and keys now carries functions and imports). L3 plugs
into the existing surprise loop.

What stays beyond this: open-ended semantic reading ("what did the
author intend?") — that is LLM territory and is served, not replaced,
by this layer.  What is REVOKED is the claim that NAWAH adds nothing
to code understanding: it now predicts change impact, and the
prediction is measured.
"""

from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path


# ── L1: facts from real code ───────────────────────────────────────
def facts_from_source(src: str, module: str = "mod") -> set[tuple]:
    """Parse Python source into a set of structural facts."""
    facts: set[tuple] = set()
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return {("invalid_syntax", module)}
    facts.add(("module", module))
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            facts.add(("defines", module, node.name))
            for inner in ast.walk(node):
                if isinstance(inner, ast.Call) and isinstance(
                    inner.func, ast.Name
                ):
                    facts.add(("calls", node.name, inner.func.id))
        elif isinstance(node, ast.ClassDef):
            facts.add(("class", module, node.name))
            for b in node.body:
                if isinstance(b, ast.FunctionDef | ast.AsyncFunctionDef):
                    facts.add(("method", node.name, b.name))
        elif isinstance(node, ast.Import):
            for al in node.names:
                facts.add(("imports", module, al.name))
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                facts.add(("imports", module, node.module))
    facts.add(("loc", module, min(9999, len(src.splitlines()))))
    return facts


def facts_from_file(path: str | Path, module: str | None = None) -> set[tuple]:
    p = Path(path)
    mod = module or p.stem
    return facts_from_source(p.read_text(encoding="utf-8"), mod)


def facts_from_tree(root: str | Path, pattern: str = "*.py") -> set[tuple]:
    rootp = Path(root)
    out: set[tuple] = set()
    for f in sorted(rootp.rglob(pattern)):
        if "__pycache__" in f.parts:
            continue
        rel = f.relative_to(rootp)
        mod = ":".join(rel.with_suffix("").parts)
        out |= facts_from_file(f, module=mod)
    return out


# ── fact deltas: the language of edit operators ────────────────────
def fact_delta(before: set[tuple], after: set[tuple]):
    return after - before, before - after


def diff_sources(
    src_before: str, src_after: str, module: str = "mod"
) -> tuple[set, set]:
    """What an edit adds and removes, in facts."""
    return fact_delta(
        facts_from_source(src_before, module),
        facts_from_source(src_after, module),
    )


# ── L2: edit operators on the world model ──────────────────────────
def edit_action(kind: str, target: str, name: str = "") -> str:
    """Canonical action string so lifting sees stable arguments."""
    return f"{kind}:{target}:{name}" if name else f"{kind}:{target}"


@dataclass
class CodeWorld:
    """A world model specialised to code facts, with measurement."""

    model: object = None
    predictions: int = 0
    correct: int = 0

    def __post_init__(self):
        if self.model is None:
            from .worldmodel import WorldModel

            self.model = WorldModel()

    def observe_edit(
        self, action: str, before: set[tuple], after: set[tuple]
    ) -> bool:
        """Learn one edit operator from a fact-level before/after."""
        return self.model.observe(action, frozenset(before), frozenset(after))

    def predict_edit(self, action: str, before: set[tuple]) -> set | None:
        """What will this edit do to these facts? None = honest unknown."""
        pred = self.model.predict(frozenset(before), action)
        return None if pred is None else set(pred)

    def score_prediction(
        self, action: str, before: set[tuple], after: set[tuple]
    ) -> bool:
        """Call after a real edit: was the prediction right?"""
        self.predictions += 1
        pred = self.predict_edit(action, before)
        ok = pred == set(after)
        self.correct += int(ok)
        return ok

    @property
    def accuracy(self) -> float:
        return self.correct / self.predictions if self.predictions else 0.0

    def impact(self, action: str, before: set[tuple]) -> dict:
        """Predicted change impact — the 'what will break/appear' view."""
        pred = self.predict_edit(action, before)
        if pred is None:
            return {"known": False, "delta_add": [], "delta_del": []}
        add, dele = fact_delta(set(before), pred)
        return {
            "known": True,
            "delta_add": sorted(":".join(map(str, a)) for a in add),
            "delta_del": sorted(":".join(map(str, a)) for a in dele),
            "predicted_end": sorted(":".join(map(str, a)) for a in pred),
        }


# ── executable oracles: the L3 verification facts ──────────────────
def oracle_facts(cmd: str, tag: str = "tests") -> set[tuple]:
    """Run an oracle command (pytest, lint, tsc...). Its exit status is
    a fact — the verification layer of 'understanding'."""
    import subprocess

    try:
        r = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=120
        )
        ok = r.returncode == 0
    except Exception:
        ok = False
    return {(tag, "passing") if ok else (tag, "failing")}


def scan_summary(facts: set[tuple]) -> dict:
    defs = [a for a in facts if a[0] == "defines"]
    cls = [a for a in facts if a[0] == "class"]
    imp = [a for a in facts if a[0] == "imports"]
    calls = [a for a in facts if a[0] == "calls"]
    return {
        "modules": len([a for a in facts if a[0] == "module"]),
        "functions": len(defs),
        "classes": len(cls),
        "imports": len(imp),
        "call_edges": len(calls),
        "invalid": any(a[0] == "invalid_syntax" for a in facts),
    }
