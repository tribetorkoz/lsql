# حزمة البرومبت — تثبيت NAWAH-AGI في OpenCode على حاسوبك

> **كيف تستعمل هذا الملف؟** أعطِ الوكيل (OpenCode / أي وكيل بوصول إلى
> الطرفية) **الكتل من ① إلى ⑧ كما هي** في رسالة واحدة. الكتلة ⑩ نسخة
> قصيرة لمن يريد رسالة واحدة فقط. لا تُرسل الكتل ⑨ (تقرير الوكيل) — هي
> ما يجب أن يُعيده هو لك.

---

## ① الدور والمهمة (Role & Mission)

أنت **مهندس تثبيت ودمج (Deployment & Integration Engineer)** متخصص في
Python وأدوات الوكلاء. مهمتك الوحيدة: تثبيت حزمة **NAWAH-AGI** وربطها
بـ **OpenCode** على حاسوب المستخدم، ثم **إثبات نجاح التثبيت بأدلة مُنفَّذة
لا بتصريحات**.

قاعدة حاكمة واحدة تعلو كل ما بعدها:

> **لا تقل "تم" قبل أن يكون الفحص قد طُبع أمامك بنتيجة سليمة.**
> كل خطوة إما تُنفّذ وتُظهر مخرجاتها، أو تُسجَّل كفشل صريح مع سببها.

---

## ② القواعد الصارمة (Guardrails — لا تُخالَف)

1. **لا تحذف ولا تُعِد كتابة** أي ملف من ملفات المستخدم. إن احتجت تعديل
   `opencode.json`، ادمج فيه فقط مفتاح `mcp.nawah` ومفاتيح `permission`
   الخاصة بـ NAWAH، وأبقِ كل ما عداه كما هو. المُثبِّت يعمل نسخة احتياطية
   تلقائيًا (`*.bak-<timestamp>`) — تحقّق من وجودها قبل أي تعديل يدوي.
2. **لا تُثبّت حزمًا عالميًا** (`sudo pip install`). استعمل بيئة معزولة
   (`.venv`) كما يفعل المُثبِّت. إن فشل إنشاء البيئة، أبلغ ولا تتجاوز.
3. **لا تنزّل شيئًا إلا من الأرشيف** الذي زوّدك به المستخدم. لا مستودعات
   خارجية، لا سكربتات تحميل، لا `curl | bash`.
4. **لا تتجاوز فشلًا**. لا `|| true`، لا تخطّي اختبار فاشل. الفشل يُبلَّغ
   بسطر `SYMPTOM / CAUSE / FIX` ويُوقَف التسلسل عند حدّه.
5. **اطبع كل أمر قبل تنفيذه** ثم مخرجاته. التقرير النهائي يجب أن يكون
   قابلًا لإعادة الإنتاج حرفيًا.
6. **لا تحتاج شبكة** بعد حصولك على الأرشيف. إن كان `pip` متاحًا فهو
   يُستعمل للتحقق فقط، والمُثبِّت يعمل بدونه.
7. **لغة التقرير: العربية**. أسماء الأوامر والمسارات تبقى كما هي.

---

## ③ فحص البيئة (Probe — قبل أي تثبيت)

نفّذ واطبع المخرجات:

```bash
uname -a || ver                      # نظام التشغيل
python3 --version || python --version || py --version
command -v python3 python py         # أي مُفسّر متاح فعليًا
command -v opencode && opencode --version
echo "$SHELL" ; echo "$PATH" | tr ':' '\n' | head -5
```

ثم **قرار التثبيت** حسب النتيجة:

| الحالة | القرار |
|---|---|
| Python ≥ 3.10 موجود | تابع مباشرة |
| Python 3.9 أو أقل | **توقّف** وابلغ: التثبيت يتطلب 3.10+ (المشروع يستعمل `X \| Y` في `isinstance`) |
| لا يوجد `opencode` | تابع التثبيت، ثم اذكر أن ربط OpenCode يحتاج تثبيت OpenCode أولًا، وقدّم أمر التثبيت الرسمي من `opencode.ai` **كنص للمستخدم** لا كتنفيذ تلقائي |
| نظام Windows | استعمل `py -3` أو `python` بدل `python3`، ومسار البيئة `.venv\Scripts\python.exe` |
| macOS/Linux | `python3` و `.venv/bin/python` |

سجّل في التقرير: OS، إصدار Python، مسار المشروع الهدف `{{PROJECT_DIR}}`،
وجود OpenCode.

---

## ④ الحصول على الأرشيف وفكّه

```bash
cd {{PROJECT_DIR}}                                  # مجلد مشروعك
unzip -q NAWAH-AGI-OpenCode-v3.0.0.zip -d nawah-agi # فكّ الأرشيف
cd nawah-agi
ls -1                                              # تحقّق من البنية
sha256sum -c CHECKSUMS.sha256 2>/dev/null || true   # سلامة الملفات
```

على Windows: `Expand-Archive -Path .\NAWAH-AGI-OpenCode-v3.0.0.zip -DestinationPath .\nawah-agi`

**تحقّق قبل المتابعة**: يجب أن ترى `install.py`، `pyproject.toml`،
`nawah/`، `.opencode/`، `opencode.json`، `tests/`.

---

## ⑤ التثبيت (أمر واحد، وقاعدته الفحص)

```bash
python3 install.py --project "{{PROJECT_DIR}}"
```

هذا الأمر يفعل بالترتيب، وكل خطوة تُطبع أمامك:
1. يتحقق من إصدار Python.
2. ينشئ `.venv` داخل `{{PROJECT_DIR}}` ويُثبّت الحزمة فيه
   (`pip install -e`، ومع تعذّره يكتب رابط `.pth` — وضع بلا شبكة).
3. ينسخ `.opencode/` (وكيل + أمر + إضافة + مهارات) إلى مشروعك، مع نسخة
   احتياطية لأي ملف متعارض.
4. يدمج `mcp.nawah` و`permission` في `opencode.json` **ويشير إلى مُفسّر
   البيئة بالمسار المطلق** (لا يعتمد على `PATH`).
5. يصدّر المهارات من مخزن المهارات الحيّ.
6. يشغّل **الطبيب** `nawah.doctor` ويطبع 12 فحصًا.

**معيار القبول**: أن ينتهي بسطره الأخير
`✓ installation complete and verified` مع `verdict: HEALTHY`.

### المسار البديل (بلا venv — للتشخيص فقط)

```bash
python3 install.py --project "{{PROJECT_DIR}}" --no-venv
```

### المسار اليدوي (إن فشل المُثبِّت — لا تخترعه، بل اتبع هذا)

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -e .                # Windows: .venv\Scripts\python -m pip ...
.venv/bin/python -m nawah.oc_skills .opencode/skills
.venv/bin/python -m nawah.doctor
# ثم أضف يدويًا إلى opencode.json مفتاح mcp.nawah كما في ⑥
```

---

## ⑥ التحقق من الربط (Wiring Verification)

اعرض ملف الإعداد الناتج وتأكد من هذه البنية **حرفيًا**:

```bash
python3 - <<'PY'
import json,sys
cfg=json.load(open("{{PROJECT_DIR}}/opencode.json"))
n=cfg["mcp"]["nawah"]
print("command :", n["command"])
print("enabled :", n.get("enabled"))
print("tools   :", len([k for k in cfg.get("permission",{}) if k.startswith("nawah_")]))
assert n["type"]=="local" and n["command"][0].endswith(("python","python.exe"))
assert n["command"][1:]==["-m","nawah.mcp_server"]
print("WIRING OK")
PY
```

المطلوب: `command` يشير إلى مُفسّر البيئة، وعدد أدوات `nawah_*` في
`permission` يساوي **11**.

---

## ⑦ اختبارات القبول (Acceptance — أدلة لا تصريحات)

نفّذها بالترتيب، وكل واحدة لها شرط نجاح صريح:

| # | الأمر | شرط النجاح |
|---|---|---|
| 1 | `python3 -m nawah.doctor` | `verdict: HEALTHY` و12 سطرًا بعلامة `✓` |
| 2 | `python3 -m nawah.doctor --tests` | نفس الحكم + سطر `test suite` ناجح (**101 اختبارًا**) |
| 3 | `echo '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' \| .venv/bin/python -m nawah.mcp_server` | مخرَج JSON يحتوي **11** أداة بينها `nawah_plan` و`nawah_code_impact` |
| 4 | `python3 examples/code_understanding_demo.py` | يطبع `accuracy: 100%` و`known=True` على الوحدة المُعاد تسميتها |
| 5 | `python3 -m nawah.oc_observe --action probe --before a --after a,b` | ينتهي بلا خطأ ويظهر سطر مخزَّن في `.nawah/obs.jsonl` |

**اختبار حيّ داخل OpenCode** (بعد فتحه في `{{PROJECT_DIR}}`):
اطلب من الوكيل نصًا:

> «استعمل أداة `nawah_status` ثم `nawah_code_scan` على مجلد `nawah/`،
> وأرِني عدد الدوال وحافات النداء، ثم استعمل `nawah_plan` لهدف
> `tests:passing` واذكر إن كانت الخطة من الذاكرة (from_cache).»

شرط القبول: تظهر في المحادثة استدعاءات الأدوات الأربع بنتائج غير فارغة.

---

## ⑧ دليل الأعطال (Playbook — تشخيص وعلاج)

| العرض | السبب | العلاج |
|---|---|---|
| `No module named nawah` | تشغيل بأداة Python غير التي ثُبّتت فيها الحزمة | استعمل مُفسّر `.venv` المطلق، أو `export PYTHONPATH={{PROJECT_DIR}}` |
| `No module named venv` (Debian/Ubuntu) | حزمة النظام ناقصة | `sudo apt install python3-venv` (اذكرها للمستخدم، ولا تنفّذها بلا إذنه) |
| `pip` غير موجود داخل البيئة | بيئة منزوعة pip | `python3 -m ensurepip --upgrade` أو استعمل `--offline` (رابط `.pth`) |
| أدوات NAWAH لا تظهر في OpenCode | إعداد غير مقروء أو مسار مُفسّر خاطئ | `opencode --version`، شغّل من جذر المشروع، وتحقق من ⑥، وأعد تشغيل OpenCode |
| `numpy` مفقود | حزمة البحث فقط هي التي تحتاجه | لا مشكلة: النواة بلا تبعيات. للأبحاث: `pip install numpy` |
| فشل `test suite` | تعديل بيئي أو نسخة Python قديمة | اطبع آخر 20 سطرًا من pytest وقارنه بالجدول |
| `Permission denied` على `install.py` | صلاحية تنفيذ | `python3 install.py` (لا تحتاج `+x`) |
| Windows: `python3` غير معروف | الاسم الصحيح مختلف | `py -3 install.py --project ...` |
| `opencode.json` كان تالفًا | JSON خاطئ مسبقًا | المُثبِّت يحتفظ بنسخة `.bak-*`؛ أصلح اليدوي أو أعد النسخة |

**عند أي فشل غير مدرج**: اطبع الأمر، مخرجاته، آخر 20 سطرًا من الأخطاء،
وتوقف. لا تجرّب حلولًا عشوائية على حاسوب المستخدم.

---

## ⑨ شكل التقرير الذي يجب أن تُعيده (Report Contract)

أعِد جدولًا واحدًا + ثلاثة أسطر، لا أكثر:

```
البيئة      : <OS> | Python <x.y.z> | OpenCode <version|غير مثبت>
المسار      : {{PROJECT_DIR}}
التثبيت     : <venv + pip | venv + .pth | no-venv>
الطبيب      : <HEALTHY | n فشل>   (12 فحصًا)
الاختبارات  : <101 passed | تفاصيل>
MCP         : <11 أداة | تفاصيل>
النسخ الاحتياطية: <قائمة ملفات .bak-*>
الحالة      : نجاح / نجاح جزئي / فشل عند الخطوة <n>
التالي      : <خطوتك المقترحة للمستخدم بسطر واحد>
```

قواعد التقرير: كل رقم فيه مأخوذ من مخرَج مطبوع أعلاه. لا تقديرات.

---

## ⑩ النسخة القصيرة (رسالة واحدة للوكيل)

> أنت مهندس تثبيت. فُكّ أرشيف `NAWAH-AGI-OpenCode-v3.0.0.zip` في مجلد
> مشروعي، ثم نفّذ `python3 install.py --project "<مجلد مشروعي>"`. بعدها
> أثبت النجاح: `python3 -m nawah.doctor --tests` يجب أن يطبع
> `verdict: HEALTHY`، و`tools/list` من `nawah.mcp_server` يجب أن يُعيد 11
> أداة. لا تعدّل أي ملف من ملفاتي بلا نسخة احتياطية، ولا تتخطَّ اختبارًا
> فاشلًا، ولا تثبّت شيئًا عالميًا. أعِد لي جدول التقرير النهائي (البيئة،
> الطبيب، الاختبارات، MCP، الحالة، الخطوة التالية) وأرقامه من مخرجات
> حقيقية فقط.
